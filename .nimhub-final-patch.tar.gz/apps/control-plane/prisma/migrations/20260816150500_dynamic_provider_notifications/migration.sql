-- Snapshot notifications per user and make PasarGuard provider configuration switchable at runtime.
CREATE TYPE "NotificationCategory" AS ENUM ('ACCOUNT', 'SERVICE', 'ACCOUNT_STATUS', 'SYSTEM', 'SUPPORT');

ALTER TABLE "Notification"
  ADD COLUMN "category" "NotificationCategory" NOT NULL DEFAULT 'SYSTEM';

ALTER TABLE "Plan"
  ADD COLUMN "pasarGuardProviderKey" TEXT,
  ADD COLUMN "pasarGuardProfileKey" TEXT;

ALTER TABLE "PasarGuardBinding"
  ADD COLUMN "providerKey" TEXT,
  ADD COLUMN "profileKey" TEXT;

DROP INDEX IF EXISTS "PasarGuardBinding_externalUserId_key";
CREATE UNIQUE INDEX "PasarGuardBinding_providerKey_externalUserId_key"
  ON "PasarGuardBinding"("providerKey", "externalUserId");
CREATE INDEX "PasarGuardBinding_providerKey_idx" ON "PasarGuardBinding"("providerKey");

CREATE TABLE "PasarGuardProviderConfig" (
  "id" TEXT NOT NULL,
  "baseUrl" TEXT NOT NULL,
  "username" TEXT NOT NULL,
  "passwordCiphertext" TEXT NOT NULL,
  "providerKey" TEXT NOT NULL,
  "profileSnapshot" JSONB,
  "freeProfileKey" TEXT,
  "lastStatus" TEXT,
  "lastTestAt" TIMESTAMP(3),
  "lastSyncAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "PasarGuardProviderConfig_pkey" PRIMARY KEY ("id")
);

-- Preserve existing public notifications for accounts that already existed at publication time.
-- Future notifications are always materialized into NotificationDelivery rows at send time.
INSERT INTO "NotificationDelivery" ("notificationId", "userId", "deliveredAt", "readAt")
SELECT n."id", u."id", COALESCE(n."publishedAt", n."createdAt"), NULL
FROM "Notification" n
JOIN "User" u
  ON u."createdAt" <= COALESCE(n."publishedAt", n."createdAt")
 AND u."status" <> 'DELETED'
WHERE n."audience" = 'ALL'
ON CONFLICT ("notificationId", "userId") DO NOTHING;

-- Preserve legacy FREE/PAID notices only for users that both existed when the
-- notice was published and matched that audience through an existing service.
INSERT INTO "NotificationDelivery" ("notificationId", "userId", "deliveredAt", "readAt")
SELECT DISTINCT n."id", u."id", COALESCE(n."publishedAt", n."createdAt"), NULL
FROM "Notification" n
JOIN "User" u
  ON u."createdAt" <= COALESCE(n."publishedAt", n."createdAt")
 AND u."status" <> 'DELETED'
JOIN "Service" s ON s."userId" = u."id"
WHERE (n."audience" = 'FREE' AND s."isFree" = TRUE)
   OR (n."audience" = 'PAID' AND s."isFree" = FALSE)
ON CONFLICT ("notificationId", "userId") DO NOTHING;

-- Keep the block event integrated with the categorized, per-user inbox.
CREATE OR REPLACE FUNCTION "nimhub_notify_suspended_user"()
RETURNS trigger AS $$
DECLARE
  notification_id TEXT;
BEGIN
  IF NEW."status" = 'SUSPENDED' AND OLD."status" IS DISTINCT FROM NEW."status" THEN
    notification_id := 'susp_' || substr(md5(NEW."id" || clock_timestamp()::text || random()::text), 1, 20);

    INSERT INTO "Notification" (
      "id", "title", "body", "category", "audience", "actionUrl", "publishedAt", "expiresAt", "createdAt", "updatedAt"
    ) VALUES (
      notification_id,
      'حساب شما مسدود شد',
      'دسترسی حساب و سرویس‌های شما توسط مدیریت مسدود شده است. برای پیگیری با پشتیبانی تماس بگیرید.',
      'ACCOUNT_STATUS',
      'SELECTED',
      'nimhub://account/suspended',
      CURRENT_TIMESTAMP,
      NULL,
      CURRENT_TIMESTAMP,
      CURRENT_TIMESTAMP
    );

    INSERT INTO "NotificationDelivery" ("notificationId", "userId", "deliveredAt", "readAt")
    VALUES (notification_id, NEW."id", CURRENT_TIMESTAMP, NULL);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;
