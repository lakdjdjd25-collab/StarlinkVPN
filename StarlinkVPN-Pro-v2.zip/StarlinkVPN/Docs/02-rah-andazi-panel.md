# راه‌اندازی StarlinkPanel

## پیش‌نیازها

- PHP 8.1 یا جدیدتر
- `pdo_sqlite`
- `curl`
- `fileinfo`
- HTTPS معتبر
- امکان نوشتن در مسیر دیتابیس و فیش‌ها

## آپلود روی هاست معمولی

محتویات داخل `StarlinkPanel` باید مستقیماً در Document Root قرار گیرد:

```text
htdocs/
├── index.php
├── api.php
├── config.php
├── helpers.php
├── db.php
├── pasargad.php
├── uploads/
└── .htaccess
```

آدرس‌های تست:

```text
https://YOUR-DOMAIN/index.php
https://YOUR-DOMAIN/api.php?action=health
https://YOUR-DOMAIN/api.php?action=config
```

پاسخ health باید JSON و شامل `"ok":true` باشد.

## استقرار پیشنهادی روی Railway یا VPS

پوشه `StarlinkPanel` دارای `Dockerfile` و `railway.json` است.

برای Railway:

1. همین پروژه را در GitHub قرار دهید.
2. در Railway، Root Directory سرویس را روی `StarlinkPanel` بگذارید.
3. یک Volume دائمی با Mount Path برابر `/data` اضافه کنید.
4. متغیر `STARLINK_DATA_DIR=/data` در Dockerfile از قبل تنظیم شده است.
5. دامنه HTTPS سرویس را پس از استقرار در `AppConfig.kt` و `AppConfig.swift` قرار دهید.

در حالت هاست معمولی که متغیر محیطی تعریف نشده، دیتابیس و uploads همان داخل پوشه `StarlinkPanel` باقی می‌مانند؛ بنابراین ساختار قبلی حفظ شده است.

## نکته مهم InfinityFree

صفحه وب مدیریت ممکن است روی InfinityFree باز شود، اما هاست رایگان InfinityFree برای API موبایل مناسب نیست و درخواست مستقیم Android/iPhone را با سیستم امنیت مرورگر مسدود می‌کند. برای نسخه واقعی اپ، API باید روی Railway، VPS یا هاست عادی بدون این محدودیت باشد.

## مجوزهای فایل

روی VPS:

```bash
chmod 755 StarlinkPanel
chmod 775 StarlinkPanel/uploads
```

در Docker/Railway، مسیر `/data` به‌صورت خودکار آماده می‌شود.

## امنیت

- `config.php` و `data.db` از دسترسی مستقیم وب مسدود شده‌اند.
- اجرای PHP داخل `uploads` بسته شده است.
- فیش‌ها از URL عمومی سرو نمی‌شوند و فقط از پنل احراز هویت‌شده قابل مشاهده‌اند.
- گواهی SSL پاسارگاد بررسی می‌شود و نباید Self-signed نامعتبر باشد.
