# بیلد Android و iPhone

## Android

### روش ساده با GitHub Actions

1. کل پوشه `StarlinkVPN` را در GitHub قرار دهید.
2. وارد تب **Actions** شوید.
3. Workflow با نام **Build Android APK** را اجرا کنید.
4. Workflow مخزن رسمی XTLS/libXray را بیلد می‌کند، AAR را داخل پروژه می‌گذارد و `app-debug.apk` را به‌صورت Artifact تحویل می‌دهد.

این روش نیاز به قرار دادن دستی AAR در GitHub ندارد.

### روش محلی

پیش‌نیازها:

- Android Studio / Android SDK 35
- JDK 17
- Go، Git و Python 3
- Gradle 8.9

```bash
cd StarlinkVPN-Android
./build-libxray-android.sh
./build-apk.sh
```

خروجی:

```text
app/build/outputs/apk/debug/app-debug.apk
```

فایل هسته باید در این مسیر باشد:

```text
StarlinkVPN-Android/app/libs/libXray.aar
```

## iPhone

بیلد iOS فقط روی macOS با Xcode انجام می‌شود.

پیش‌نیازها:

- Xcode و iOS Simulator Runtime
- حساب Apple Developer
- فعال بودن Network Extensions برای App ID
- Go، Git، Python 3 و XcodeGen

```bash
cd StarlinkVPN-iOS
./build-libxray-ios.sh
brew install xcodegen
xcodegen generate
open StarlinkVPN.xcodeproj
```

در Xcode:

1. Team را برای هر دو Target انتخاب کنید.
2. Bundle IDهای App و PacketTunnel را با App IDهای حساب خود هماهنگ کنید.
3. Capability مربوط به Network Extensions / Packet Tunnel را فعال کنید.
4. ابتدا روی دستگاه واقعی تست کنید؛ VPN Extension روی Simulator معیار نهایی نیست.
5. Archive بگیرید و برای TestFlight یا Ad Hoc امضا کنید.

## API پنل

در حال حاضر هر دو اپ به آدرس زیر تنظیم شده‌اند:

```text
https://starlinkpanel.infinityfreeapp.com
```

برای کارکرد واقعی اپ موبایل باید این مقدار را به دامنه API-capable خود تغییر دهید:

- Android: `StarlinkVPN-Android/app/src/main/java/com/starlink/vpn/AppConfig.kt`
- iPhone: `StarlinkVPN-iOS/AppConfig.swift`

## تست انتها به انتها

1. `api.php?action=health` پاسخ JSON بدهد.
2. اپ لیست پلن و کارت را نمایش دهد.
3. فیش ثبت و کد رهگیری ذخیره شود.
4. مدیر سفارش را تأیید کند.
5. پاسارگاد Subscription برگرداند.
6. اپ سرورها را نشان دهد.
7. با مجوز VPN، اتصال برقرار و اعلان/وضعیت سیستم فعال شود.
