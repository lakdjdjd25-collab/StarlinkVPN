#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
[ -f app/libs/libXray.aar ] || ./build-libxray-android.sh
if command -v gradle >/dev/null 2>&1; then
  gradle --no-daemon :app:assembleDebug
elif [ -x ./gradlew ] && [ -f gradle/wrapper/gradle-wrapper.jar ]; then
  ./gradlew --no-daemon :app:assembleDebug
else
  echo 'Gradle 8.9 نصب نیست. پروژه را در Android Studio باز کنید یا GitHub Action را اجرا کنید.' >&2
  exit 1
fi
echo "APK: $ROOT/app/build/outputs/apk/debug/app-debug.apk"
