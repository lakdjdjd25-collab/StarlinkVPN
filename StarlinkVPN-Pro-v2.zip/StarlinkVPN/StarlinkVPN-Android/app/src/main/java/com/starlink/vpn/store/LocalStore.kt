package com.starlink.vpn.store

import android.content.Context
import com.starlink.vpn.model.PendingOrder

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("starlink_state", Context.MODE_PRIVATE)
    var subscriptionUrl: String?
        get() = prefs.getString("subscription_url", null)
        set(value) = prefs.edit().putString("subscription_url", value).apply()
    var contact: String
        get() = prefs.getString("contact", "") ?: ""
        set(value) = prefs.edit().putString("contact", value).apply()
    var selectedServerUri: String?
        get() = prefs.getString("selected_server_uri", null)
        set(value) = prefs.edit().putString("selected_server_uri", value).apply()
    fun savePending(order: PendingOrder?) {
        prefs.edit().apply {
            if (order == null) remove("order_track").remove("order_token").remove("order_plan")
            else putString("order_track", order.trackCode).putString("order_token", order.orderToken).putString("order_plan", order.planTitle)
        }.apply()
    }
    fun pendingOrder(): PendingOrder? {
        val track = prefs.getString("order_track", null) ?: return null
        val token = prefs.getString("order_token", null) ?: return null
        return PendingOrder(track, token, prefs.getString("order_plan", "") ?: "")
    }
}
