package com.starlink.vpn.net

import com.starlink.vpn.model.*
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.UUID

class PanelApi(private val baseUrl: String) {
    private val base = baseUrl.trimEnd('/')

    fun getConfig(): PanelConfig {
        val j = request("GET", "/api.php?action=config")
        val plansJson = j.getJSONArray("plans")
        val plans = buildList {
            for (i in 0 until plansJson.length()) {
                val p = plansJson.getJSONObject(i)
                add(Plan(p.getString("id"), p.getString("title"), p.getInt("days"), p.getInt("gb"), p.getLong("price")))
            }
        }
        val card = j.getJSONObject("card")
        return PanelConfig(plans, CardInfo(card.optString("number"), card.optString("holder")), j.optString("brand", "Starlink Vpn"), j.optString("telegram"), j.optInt("poll_seconds", 8))
    }

    fun orderStatus(track: String, token: String): OrderStatus {
        val path = "/api.php?action=order_status&track=${enc(track)}&token=${enc(token)}"
        val j = request("GET", path)
        return OrderStatus(j.optBoolean("ok"), j.optString("status"), j.optString("sub_url").ifBlank { null }, j.optString("note").ifBlank { null }, j.optString("vpn_username").ifBlank { null })
    }

    fun submitReceipt(planId: String, contact: String, image: ByteArray, fileName: String, mime: String): OrderSubmission {
        val boundary = "----Starlink${UUID.randomUUID()}"
        val body = ByteArrayOutputStream().apply {
            fun field(name: String, value: String) {
                write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
            }
            field("plan_id", planId)
            field("contact", contact)
            write("--$boundary\r\nContent-Disposition: form-data; name=\"receipt\"; filename=\"${fileName.replace("\"", "")}\"\r\nContent-Type: $mime\r\n\r\n".toByteArray())
            write(image)
            write("\r\n--$boundary--\r\n".toByteArray())
        }.toByteArray()
        val j = request("POST", "/api.php?action=submit_receipt", body, "multipart/form-data; boundary=$boundary")
        return OrderSubmission(j.getString("track_code"), j.getString("order_token"))
    }

    fun downloadText(url: String): String {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000; readTimeout = 30_000; requestMethod = "GET"
            setRequestProperty("User-Agent", "StarlinkVPN-Android/2.0")
        }
        return c.useResponseText()
    }

    private fun request(method: String, path: String, body: ByteArray? = null, contentType: String? = null): JSONObject {
        val c = (URL(base + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method; connectTimeout = 15_000; readTimeout = 35_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("X-Client-Platform", "android")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", contentType ?: "application/json")
                setFixedLengthStreamingMode(body.size)
                outputStream.use { it.write(body) }
            }
        }
        val text = c.useResponseText()
        val json = runCatching { JSONObject(text) }.getOrElse { throw IllegalStateException("پاسخ پنل معتبر نیست.") }
        if (!json.optBoolean("ok", true)) throw IllegalStateException(json.optString("error", "خطای پنل"))
        return json
    }

    private fun HttpURLConnection.useResponseText(): String {
        return try {
            val stream = if (responseCode in 200..299) inputStream else errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (responseCode !in 200..299) {
                val message = runCatching { JSONObject(text).optString("error") }.getOrNull().orEmpty()
                throw IllegalStateException(message.ifBlank { "خطای ارتباط با پنل ($responseCode)" })
            }
            text
        } finally { disconnect() }
    }

    private fun enc(value: String) = URLEncoder.encode(value, StandardCharsets.UTF_8.name())
}
