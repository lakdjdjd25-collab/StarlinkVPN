package com.starlink.vpn.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.starlink.vpn.AppConfig
import com.starlink.vpn.model.*
import kotlinx.coroutines.delay

private val BG = Color(0xFF282735)
private val SURFACE = Color(0xFF343344)
private val GREEN = Color(0xFF4CD964)
private val RED = Color(0xFFE14840)
private val YELLOW = Color(0xFFF4B912)
private val TEXT2 = Color.White.copy(alpha = .55f)

enum class AppPage { HOME, SERVERS, PURCHASE }

@Composable
fun StarlinkApp(vm: VpnViewModel, onConnectRequest: () -> Unit) {
    var page by remember { mutableStateOf(AppPage.HOME) }
    val message by vm.message.collectAsStateWithLifecycle()
    MaterialTheme(colorScheme = darkColorScheme(primary = YELLOW, background = BG, surface = SURFACE)) {
        Box(Modifier.fillMaxSize().background(BG)) {
            when (page) {
                AppPage.HOME -> HomeScreen(vm, onConnectRequest, { page = AppPage.SERVERS }, { page = AppPage.PURCHASE })
                AppPage.SERVERS -> ServersScreen(vm) { page = AppPage.HOME }
                AppPage.PURCHASE -> PurchaseScreen(vm) { page = AppPage.HOME }
            }
            if (message != null) {
                Snackbar(
                    modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                    action = { TextButton(onClick = vm::clearMessage) { Text("بستن") } }
                ) { Text(message.orEmpty()) }
            }
        }
    }
}

@Composable
fun HomeScreen(vm: VpnViewModel, onConnectRequest: () -> Unit, openServers: () -> Unit, openPurchase: () -> Unit) {
    val status by vm.status.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    val error by vm.error.collectAsStateWithLifecycle()
    val traffic by vm.traffic.collectAsStateWithLifecycle()
    val since by vm.connectedSince.collectAsStateWithLifecycle()
    val order by vm.pendingOrder.collectAsStateWithLifecycle()
    val orderState by vm.orderStatus.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(since, status) { while (status == VpnStatus.CONNECTED) { now = System.currentTimeMillis(); delay(1000) } }
    val elapsed = since?.let { ((now - it) / 1000).coerceAtLeast(0) } ?: 0

    Column(Modifier.fillMaxSize().background(BG).padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            MiniButton("★", YELLOW, openPurchase)
            Spacer(Modifier.width(8.dp))
            MiniButton("▦", Color.White.copy(.08f), openServers)
            Spacer(Modifier.weight(1f))
            Text(AppConfig.BRAND, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            MiniButton("✈", Color(0xFF2AA3E0)) {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.TELEGRAM_CHANNEL))
                runCatching { vm.getApplication<android.app.Application>().startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
        }

        Spacer(Modifier.height(34.dp))
        Text("Connecting Time", color = TEXT2, fontSize = 13.sp)
        Text(formatDuration(elapsed), color = Color.White, fontSize = 38.sp, modifier = Modifier.padding(top = 10.dp))
        Spacer(Modifier.height(22.dp))

        Surface(color = Color.White.copy(.035f), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().clickable(onClick = openServers)) {
            Row(Modifier.padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("‹", color = Color.White, fontSize = 28.sp)
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(selected?.remark ?: "سروری انتخاب نشده", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
                    Text(selected?.let { "${it.protocol.uppercase()} · ${if (it.pingMs >= 0) "${it.pingMs} ms" else "در انتظار تست"}" } ?: "برای انتخاب لمس کنید", color = TEXT2, fontSize = 11.sp)
                }
                Box(Modifier.size(44.dp).clip(CircleShape).background(if (selected != null) GREEN.copy(.22f) else Color.Gray.copy(.35f)), contentAlignment = Alignment.Center) {
                    Text(if (selected != null) "✓" else "?", color = Color.White)
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            TrafficItem("Upload", traffic.uploadBps, "↑")
            Box(Modifier.width(1.dp).height(42.dp).background(Color.White.copy(.12f)))
            TrafficItem("Download", traffic.downloadBps, "↓")
        }

        if (order != null) {
            Surface(color = YELLOW.copy(.10f), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(top = 16.dp)) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("فیش ${order!!.planTitle}", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${order!!.trackCode} · ${statusFa(orderState?.status ?: "pending")}", color = TEXT2, fontSize = 12.sp)
                    }
                    TextButton(onClick = vm::refreshOrder) { Text("بررسی") }
                }
            }
        }

        Spacer(Modifier.weight(1f))
        val connected = status == VpnStatus.CONNECTED
        val connecting = status == VpnStatus.CONNECTING
        Box(contentAlignment = Alignment.Center) {
            Surface(shape = CircleShape, color = if (connected) GREEN.copy(.15f) else Color.White.copy(.05f), modifier = Modifier.size(210.dp)) {}
            Surface(shape = CircleShape, color = Color.White.copy(.035f), modifier = Modifier.size(174.dp)) {}
            Button(
                onClick = { if (connected || connecting) vm.disconnect() else onConnectRequest() },
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3A3950)),
                modifier = Modifier.size(140.dp),
                enabled = !busy
            ) { Text("⏻", color = if (connected) GREEN else if (connecting) YELLOW else Color.White, fontSize = 48.sp) }
        }
        Spacer(Modifier.weight(1f))
        val labelColor = when (status) { VpnStatus.CONNECTED -> GREEN; VpnStatus.CONNECTING -> YELLOW; VpnStatus.ERROR -> RED; else -> RED }
        val label = when (status) { VpnStatus.CONNECTED -> "Connected"; VpnStatus.CONNECTING -> "Connecting..."; VpnStatus.ERROR -> error ?: "Error"; else -> "Not Connected" }
        Text(label, color = labelColor, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        TextButton(onClick = openPurchase, modifier = Modifier.padding(bottom = 10.dp)) { Text("خرید یا تمدید سرویس", color = YELLOW) }
    }
}

@Composable
private fun MiniButton(text: String, color: Color, action: () -> Unit) {
    Surface(shape = RoundedCornerShape(12.dp), color = color, modifier = Modifier.size(44.dp).clickable(onClick = action)) {
        Box(contentAlignment = Alignment.Center) { Text(text, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun TrafficItem(title: String, bytes: Long, icon: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = TEXT2, fontSize = 12.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(formatSpeed(bytes), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(6.dp)); Text(icon, color = TEXT2)
        }
    }
}

@Composable
fun ServersScreen(vm: VpnViewModel, back: () -> Unit) {
    val servers by vm.servers.collectAsStateWithLifecycle()
    val selected by vm.selected.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize().background(BG).padding(16.dp)) {
        Header("لیست سرورها", back) { TextButton(onClick = vm::pingServers) { Text("تست پینگ") } }
        if (servers.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("ابتدا سرویس بخرید یا منتظر تأیید فیش بمانید.", color = TEXT2, textAlign = TextAlign.Center) }
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            items(servers, key = { it.id }) { server ->
                Surface(color = if (selected?.id == server.id) GREEN.copy(.12f) else Color.White.copy(.04f), shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth().clickable { vm.select(server); back() }) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(.08f)), contentAlignment = Alignment.Center) { Text(server.protocol.take(1).uppercase(), color = Color.White) }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(server.remark, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("${server.address}:${server.port}", color = TEXT2, fontSize = 11.sp)
                        }
                        Text(if (server.pingMs >= 0) "${server.pingMs} ms" else "—", color = if (server.pingMs in 1..250) GREEN else TEXT2, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun PurchaseScreen(vm: VpnViewModel, back: () -> Unit) {
    val config by vm.panelConfig.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    var selectedPlan by remember(config) { mutableStateOf(config?.plans?.firstOrNull()) }
    var contact by remember { mutableStateOf(vm.currentContact()) }
    var receiptUri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { receiptUri = it }
    val context = LocalContext.current

    Column(Modifier.fillMaxSize().background(BG).padding(16.dp)) {
        Header("خرید سرویس", back)
        if (config == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = YELLOW) }
            return@Column
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 12.dp, horizontal = 2.dp)) {
            item { Text("انتخاب پلن", color = Color.White, fontWeight = FontWeight.Bold) }
            items(config!!.plans, key = { it.id }) { plan ->
                Surface(color = if (selectedPlan?.id == plan.id) YELLOW.copy(.15f) else Color.White.copy(.04f), shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth().clickable { selectedPlan = plan }) {
                    Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = selectedPlan?.id == plan.id, onClick = { selectedPlan = plan }, colors = RadioButtonDefaults.colors(selectedColor = YELLOW))
                        Column(Modifier.weight(1f)) { Text(plan.title, color = Color.White, fontWeight = FontWeight.Bold); Text("${plan.days} روز · ${plan.gb} گیگابایت", color = TEXT2, fontSize = 12.sp) }
                        Text("${formatPrice(plan.price)} تومان", color = YELLOW, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                Surface(color = Color.White.copy(.04f), shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("واریز به کارت", color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(config!!.card.number, color = YELLOW, fontSize = 20.sp)
                        Text("به نام ${config!!.card.holder}", color = TEXT2)
                        TextButton(onClick = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("card", config!!.card.number.replace("-", "")))
                        }) { Text("کپی شماره کارت") }
                    }
                }
            }
            item {
                OutlinedTextField(value = contact, onValueChange = { contact = it }, label = { Text("شماره تماس یا آیدی تلگرام") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            item {
                OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                    Text(if (receiptUri == null) "انتخاب تصویر فیش" else "فیش انتخاب شد ✓")
                }
            }
            item {
                Button(
                    onClick = { selectedPlan?.let { plan -> receiptUri?.let { vm.submitReceipt(plan, contact, it) } } },
                    enabled = !busy && selectedPlan != null && receiptUri != null && contact.trim().length >= 3,
                    colors = ButtonDefaults.buttonColors(containerColor = YELLOW, contentColor = Color.Black),
                    modifier = Modifier.fillMaxWidth().height(54.dp)
                ) { if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Color.Black) else Text("ارسال فیش برای تأیید", fontWeight = FontWeight.Bold) }
            }
            item { Text("پس از تأیید مدیر، لینک پاسارگاد به‌صورت خودکار داخل برنامه فعال و سرورها نمایش داده می‌شوند.", color = TEXT2, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()) }
        }
    }
}

@Composable
private fun Header(title: String, back: () -> Unit, extra: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onClick = back) { Text("بازگشت") }
        Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
        Row(content = extra)
    }
}

private fun formatDuration(seconds: Long) = String.format("%02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60)
private fun formatSpeed(bytes: Long): String = when {
    bytes >= 1024 * 1024 -> String.format("%.1f MB/s", bytes / 1048576.0)
    bytes >= 1024 -> String.format("%.0f KB/s", bytes / 1024.0)
    else -> "$bytes B/s"
}
private fun formatPrice(value: Long) = java.text.NumberFormat.getIntegerInstance().format(value)
private fun statusFa(value: String) = when (value) { "approved" -> "تأیید شد"; "rejected" -> "رد شد"; else -> "در انتظار بررسی" }
