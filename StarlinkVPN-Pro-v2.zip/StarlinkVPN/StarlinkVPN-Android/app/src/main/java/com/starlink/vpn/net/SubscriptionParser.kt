package com.starlink.vpn.net

import android.util.Base64
import com.starlink.vpn.model.ServerConfig
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder

object SubscriptionParser {
    fun parseSubscriptionContent(raw: String): List<ServerConfig> {
        val decoded = decodeSubscription(raw.trim()) ?: raw
        return decoded.lineSequence()
            .map { it.trim().removeSuffix("\r") }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .mapNotNull(::parseUri)
            .distinctBy { it.rawUri }
            .toList()
    }

    private fun decodeSubscription(value: String): String? = runCatching {
        val normalized = value.replace('-', '+').replace('_', '/')
        val padding = "=".repeat((4 - normalized.length % 4) % 4)
        String(Base64.decode(normalized + padding, Base64.DEFAULT), Charsets.UTF_8).takeIf { it.contains("://") }
    }.getOrNull()

    fun parseUri(uri: String): ServerConfig? = runCatching {
        when {
            uri.startsWith("vmess://", true) -> parseVmess(uri)
            uri.startsWith("vless://", true) -> parseStandard(uri, "vless")
            uri.startsWith("trojan://", true) -> parseStandard(uri, "trojan")
            uri.startsWith("ss://", true) -> parseShadowsocks(uri)
            else -> null
        }
    }.getOrNull()

    private fun parseVmess(uri: String): ServerConfig {
        val encoded = uri.substringAfter("vmess://")
        val json = JSONObject(String(Base64.decode(encoded, Base64.DEFAULT), Charsets.UTF_8))
        val host = json.getString("add")
        val port = json.optString("port", "443").toIntOrNull() ?: 443
        val name = decode(json.optString("ps").ifBlank { host })
        return ServerConfig(stableId(uri), name, "vmess", host, port, uri)
    }

    private fun parseStandard(uriText: String, protocol: String): ServerConfig {
        val uri = URI(uriText)
        val host = uri.host ?: error("host")
        val port = if (uri.port > 0) uri.port else 443
        val name = uri.rawFragment?.let(::decode).orEmpty().ifBlank { host }
        return ServerConfig(stableId(uriText), name, protocol, host, port, uriText)
    }

    private fun parseShadowsocks(uriText: String): ServerConfig {
        val withoutFragment = uriText.substringBefore('#')
        val name = uriText.substringAfter('#', "").let(::decode)
        val body = withoutFragment.removePrefix("ss://")
        val normalized = if ('@' !in body) {
            val decoded = String(Base64.decode(body.replace('-', '+').replace('_', '/'), Base64.DEFAULT), Charsets.UTF_8)
            "ss://$decoded"
        } else uriText.substringBefore('#')
        val uri = URI(normalized)
        val host = uri.host ?: error("host")
        val port = if (uri.port > 0) uri.port else 8388
        return ServerConfig(stableId(uriText), name.ifBlank { host }, "shadowsocks", host, port, uriText)
    }

    private fun decode(value: String): String = runCatching { URLDecoder.decode(value, "UTF-8") }.getOrDefault(value)
    private fun stableId(value: String) = value.hashCode().toUInt().toString(16)
}
