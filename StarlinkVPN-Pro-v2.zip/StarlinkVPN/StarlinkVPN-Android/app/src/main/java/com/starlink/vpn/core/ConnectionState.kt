package com.starlink.vpn.core

import com.starlink.vpn.model.TrafficStats
import com.starlink.vpn.model.VpnStatus
import kotlinx.coroutines.flow.MutableStateFlow

object ConnectionState {
    val status = MutableStateFlow(VpnStatus.DISCONNECTED)
    val traffic = MutableStateFlow(TrafficStats())
    val error = MutableStateFlow<String?>(null)
    val connectedSince = MutableStateFlow<Long?>(null)
    fun onConnecting() { status.value = VpnStatus.CONNECTING; error.value = null }
    fun onConnected() { status.value = VpnStatus.CONNECTED; connectedSince.value = System.currentTimeMillis(); error.value = null }
    fun onDisconnected() { status.value = VpnStatus.DISCONNECTED; connectedSince.value = null; traffic.value = TrafficStats() }
    fun onError(message: String) { status.value = VpnStatus.ERROR; error.value = message; connectedSince.value = null }
}
