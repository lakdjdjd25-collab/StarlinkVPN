package com.starlink.vpn.model

data class ServerConfig(
    val id: String,
    val remark: String,
    val protocol: String,
    val address: String,
    val port: Int,
    val rawUri: String,
    val premium: Boolean = true,
    val pingMs: Int = -1
)
enum class VpnStatus { DISCONNECTED, CONNECTING, CONNECTED, ERROR }
data class TrafficStats(val uploadBps: Long = 0, val downloadBps: Long = 0)
data class Plan(val id: String, val title: String, val days: Int, val gb: Int, val price: Long)
data class CardInfo(val number: String = "", val holder: String = "")
data class PanelConfig(val plans: List<Plan>, val card: CardInfo, val brand: String, val telegram: String, val pollSeconds: Int = 8)
data class OrderSubmission(val trackCode: String, val orderToken: String)
data class OrderStatus(
    val ok: Boolean,
    val status: String,
    val subUrl: String? = null,
    val note: String? = null,
    val vpnUsername: String? = null
)
data class PendingOrder(val trackCode: String, val orderToken: String, val planTitle: String)
