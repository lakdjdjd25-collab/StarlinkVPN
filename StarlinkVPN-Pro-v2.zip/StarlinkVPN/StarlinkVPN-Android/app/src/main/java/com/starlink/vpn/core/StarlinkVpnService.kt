package com.starlink.vpn.core

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.starlink.vpn.R
import com.starlink.vpn.model.TrafficStats
import com.starlink.vpn.net.XrayConfigBuilder
import com.starlink.vpn.ui.MainActivity
import kotlinx.coroutines.*
import java.io.File

class StarlinkVpnService : VpnService() {
    companion object {
        const val ACTION_CONNECT = "com.starlink.vpn.CONNECT"
        const val ACTION_DISCONNECT = "com.starlink.vpn.DISCONNECT"
        const val EXTRA_CONFIG_JSON = "config_json"
        private const val CHANNEL = "starlink_vpn"
        private const val NOTIFICATION_ID = 2201
    }

    private var tun: ParcelFileDescriptor? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var coreJob: Job? = null
    private var statsJob: Job? = null
    @Volatile private var running = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_DISCONNECT -> stopVpn()
            ACTION_CONNECT -> intent.getStringExtra(EXTRA_CONFIG_JSON)?.let(::startVpn)
        }
        return START_STICKY
    }

    private fun startVpn(baseConfig: String) {
        if (running) return
        running = true
        ConnectionState.onConnecting()
        startForeground(NOTIFICATION_ID, notification("در حال اتصال..."))

        coreJob = serviceScope.launch {
            try {
                if (!XrayCore.isAvailable()) error("فایل رسمی libXray.aar به پروژه اضافه نشده است.")
                val builder = Builder()
                    .setSession("Starlink VPN")
                    .setMtu(1500)
                    .addAddress("172.19.0.1", 30)
                    .addRoute("0.0.0.0", 0)
                    .addDnsServer("1.1.1.1")
                    .addDnsServer("8.8.8.8")
                runCatching { builder.addAddress("fd00:1:fd00:1::1", 126).addRoute("::", 0) }
                builder.addDisallowedApplication(packageName)
                tun = builder.establish() ?: error("ساخت رابط VPN در اندروید ناموفق بود.")
                val config = XrayConfigBuilder.attachTunFd(baseConfig, tun!!.fd)
                val configFile = File(filesDir, "xray_config.json").apply { writeText(config) }
                XrayCore.start(this@StarlinkVpnService, configFile.absolutePath)
                if (!running) return@launch
                ConnectionState.onConnected()
                updateNotification("متصل")
                startStats()
            } catch (t: Throwable) {
                val message = (t.cause ?: t).message ?: "خطای ناشناخته اتصال"
                ConnectionState.onError(message)
                stopVpn(preserveError = true)
            }
        }
    }

    private fun startStats() {
        statsJob?.cancel()
        statsJob = serviceScope.launch {
            var previous = XrayCore.queryStats()
            while (isActive && running) {
                delay(1_000)
                val now = XrayCore.queryStats()
                ConnectionState.traffic.value = TrafficStats(
                    uploadBps = (now.first - previous.first).coerceAtLeast(0),
                    downloadBps = (now.second - previous.second).coerceAtLeast(0)
                )
                previous = now
            }
        }
    }

    private fun stopVpn(preserveError: Boolean = false) {
        if (!running && tun == null) return
        running = false
        statsJob?.cancel(); statsJob = null
        serviceScope.launch { runCatching { XrayCore.stop() } }
        runCatching { tun?.close() }; tun = null
        if (!preserveError) ConnectionState.onDisconnected()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onRevoke() { stopVpn(); super.onRevoke() }
    override fun onDestroy() { stopVpn(); serviceScope.cancel(); super.onDestroy() }

    private fun notification(text: String): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL, "Starlink VPN", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val disconnect = PendingIntent.getService(this, 1, Intent(this, StarlinkVpnService::class.java).setAction(ACTION_DISCONNECT), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL)
            .setContentTitle("Starlink VPN")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_vpn)
            .setContentIntent(open)
            .addAction(0, "قطع اتصال", disconnect)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, notification(text))
    }
}
