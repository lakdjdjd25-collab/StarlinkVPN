package com.starlink.vpn

object AppConfig {
    const val BRAND = "Starlink Vpn"
    const val TELEGRAM_CHANNEL = "https://t.me/starlink_vpnx"
    const val PANEL_BASE_URL = "https://starlinkpanel.infinityfreeapp.com"
    const val DNS_SERVER = "1.1.1.1"
    const val METRICS_PORT = 49227
}
