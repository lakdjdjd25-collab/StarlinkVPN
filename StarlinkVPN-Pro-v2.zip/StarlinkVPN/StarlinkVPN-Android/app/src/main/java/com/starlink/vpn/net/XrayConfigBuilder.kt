package com.starlink.vpn.net

import android.util.Base64
import com.starlink.vpn.AppConfig
import com.starlink.vpn.model.ServerConfig
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder

object XrayConfigBuilder {
    fun build(server: ServerConfig, tunFd: Int? = null): String {
        val root = JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put("dns", JSONObject().put("servers", JSONArray().put(AppConfig.DNS_SERVER).put("8.8.8.8")))
            .put("inbounds", JSONArray().put(tunInbound()))
            .put("outbounds", JSONArray().put(outbound(server)).put(freedom()).put(block()))
            .put("routing", JSONObject().put("domainStrategy", "IPIfNonMatch").put("rules", JSONArray()))
            .put("policy", JSONObject().put("system", JSONObject()
                .put("statsInboundDownlink", true).put("statsInboundUplink", true)
                .put("statsOutboundDownlink", true).put("statsOutboundUplink", true)))
            .put("stats", JSONObject())
            .put("metrics", JSONObject().put("listen", "127.0.0.1:${AppConfig.METRICS_PORT}"))
        if (tunFd != null) root.put("env", JSONObject().put("xray.tun.fd", tunFd.toString()))
        return root.toString()
    }

    fun attachTunFd(config: String, tunFd: Int): String = JSONObject(config)
        .put("env", JSONObject().put("xray.tun.fd", tunFd.toString())).toString()

    private fun tunInbound() = JSONObject()
        .put("tag", "tun-in")
        .put("port", 0)
        .put("protocol", "tun")
        .put("settings", JSONObject().put("name", "xray-tun").put("mtu", 1500))
        .put("sniffing", JSONObject().put("enabled", true).put("routeOnly", false)
            .put("destOverride", JSONArray().put("http").put("tls").put("quic")))

    private fun outbound(server: ServerConfig): JSONObject = when (server.protocol.lowercase()) {
        "vmess" -> vmess(server)
        "trojan" -> trojan(server)
        "shadowsocks" -> shadowsocks(server)
        else -> vless(server)
    }

    private fun vmess(server: ServerConfig): JSONObject {
        val json = JSONObject(String(Base64.decode(server.rawUri.removePrefix("vmess://"), Base64.DEFAULT), Charsets.UTF_8))
        val user = JSONObject().put("id", json.getString("id")).put("alterId", json.optInt("aid", 0)).put("security", json.optString("scy", "auto"))
        val vnext = JSONObject().put("address", server.address).put("port", server.port).put("users", JSONArray().put(user))
        return JSONObject().put("tag", "proxy").put("protocol", "vmess")
            .put("settings", JSONObject().put("vnext", JSONArray().put(vnext)))
            .put("streamSettings", stream(json.optString("net", "tcp"), json.optString("tls"), json.optString("host"), json.optString("path"), json.optString("sni"), mapOf("fp" to json.optString("fp"))))
    }

    private fun vless(server: ServerConfig): JSONObject {
        val uri = URI(server.rawUri)
        val q = query(uri.rawQuery)
        val user = JSONObject().put("id", uri.userInfo ?: "").put("encryption", q["encryption"] ?: "none")
        q["flow"]?.takeIf { it.isNotBlank() }?.let { user.put("flow", it) }
        val vnext = JSONObject().put("address", server.address).put("port", server.port).put("users", JSONArray().put(user))
        return JSONObject().put("tag", "proxy").put("protocol", "vless")
            .put("settings", JSONObject().put("vnext", JSONArray().put(vnext)))
            .put("streamSettings", stream(q["type"] ?: "tcp", q["security"], q["host"], q["path"], q["sni"], q))
    }

    private fun trojan(server: ServerConfig): JSONObject {
        val uri = URI(server.rawUri)
        val q = query(uri.rawQuery)
        val item = JSONObject().put("address", server.address).put("port", server.port).put("password", uri.userInfo ?: "")
        return JSONObject().put("tag", "proxy").put("protocol", "trojan")
            .put("settings", JSONObject().put("servers", JSONArray().put(item)))
            .put("streamSettings", stream(q["type"] ?: "tcp", q["security"] ?: "tls", q["host"], q["path"], q["sni"], q))
    }

    private fun shadowsocks(server: ServerConfig): JSONObject {
        val raw = server.rawUri.substringBefore('#').removePrefix("ss://")
        val userHost = if ('@' in raw) raw else String(Base64.decode(raw.replace('-', '+').replace('_', '/'), Base64.DEFAULT), Charsets.UTF_8)
        val credentialsRaw = userHost.substringBeforeLast('@')
        val credentials = runCatching {
            String(Base64.decode(credentialsRaw.replace('-', '+').replace('_', '/'), Base64.DEFAULT), Charsets.UTF_8)
        }.getOrDefault(credentialsRaw)
        val method = credentials.substringBefore(':')
        val password = credentials.substringAfter(':', "")
        val item = JSONObject().put("address", server.address).put("port", server.port).put("method", method).put("password", password)
        return JSONObject().put("tag", "proxy").put("protocol", "shadowsocks").put("settings", JSONObject().put("servers", JSONArray().put(item)))
    }

    private fun stream(network: String, security: String?, host: String?, path: String?, sni: String?, q: Map<String, String> = emptyMap()): JSONObject {
        val net = network.ifBlank { "tcp" }
        val result = JSONObject().put("network", net)
        when (security) {
            "tls" -> result.put("security", "tls").put("tlsSettings", JSONObject().apply {
                sni?.takeIf(String::isNotBlank)?.let { put("serverName", it) }
                q["fp"]?.takeIf(String::isNotBlank)?.let { put("fingerprint", it) }
                q["alpn"]?.takeIf(String::isNotBlank)?.let { put("alpn", JSONArray(it.split(','))) }
                if (q["allowInsecure"] == "1") put("allowInsecure", true)
            })
            "reality" -> result.put("security", "reality").put("realitySettings", JSONObject().apply {
                sni?.takeIf(String::isNotBlank)?.let { put("serverName", it) }
                q["fp"]?.takeIf(String::isNotBlank)?.let { put("fingerprint", it) }
                q["pbk"]?.let { put("publicKey", it) }
                q["sid"]?.let { put("shortId", it) }
                q["spx"]?.let { put("spiderX", it) }
            })
        }
        when (net) {
            "ws" -> result.put("wsSettings", JSONObject().put("path", path ?: "/").put("headers", JSONObject().apply { host?.takeIf(String::isNotBlank)?.let { put("Host", it) } }))
            "grpc" -> result.put("grpcSettings", JSONObject().put("serviceName", path?.removePrefix("/") ?: "").put("multiMode", q["mode"] == "multi"))
            "httpupgrade" -> result.put("httpupgradeSettings", JSONObject().put("path", path ?: "/").put("host", host ?: ""))
            "xhttp", "splithttp" -> result.put("xhttpSettings", JSONObject().put("path", path ?: "/").put("host", host ?: "").apply { q["mode"]?.let { put("mode", it) } })
            "tcp" -> if (q["headerType"] == "http") result.put("tcpSettings", JSONObject().put("header", JSONObject().put("type", "http")))
        }
        return result
    }

    private fun freedom() = JSONObject().put("tag", "direct").put("protocol", "freedom")
    private fun block() = JSONObject().put("tag", "block").put("protocol", "blackhole")
    private fun query(raw: String?): Map<String, String> = raw?.split('&')?.mapNotNull { part ->
        val i = part.indexOf('='); if (i < 0) null else part.substring(0, i) to URLDecoder.decode(part.substring(i + 1), "UTF-8")
    }?.toMap().orEmpty()
}
