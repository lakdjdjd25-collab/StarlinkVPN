package com.starlink.vpn.core

import android.net.VpnService
import com.starlink.vpn.AppConfig
import org.json.JSONObject
import java.lang.reflect.Proxy
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Runtime bridge to the official XTLS/libXray AAR.
 * The app compiles without the binary, but a real connection requires app/libs/libXray.aar.
 */
object XrayCore {
    private val running = AtomicBoolean(false)
    private var apiClass: Class<*>? = null
    private var controllerProxy: Any? = null

    fun isAvailable(): Boolean = findApiClass() != null

    fun start(service: VpnService, configPath: String) {
        val clazz = findApiClass() ?: error("هسته libXray داخل app/libs قرار نگرفته است.")
        if (!running.compareAndSet(false, true)) return
        try {
            registerSocketProtection(clazz, service)
            invokeOptional(clazz, "setDNS", controllerProxy, "${AppConfig.DNS_SERVER}:53")
            val response = invoke(clazz, envelope("runXray", JSONObject().put("configPath", configPath)))
            ensureSuccess(response)
        } catch (t: Throwable) {
            running.set(false)
            throw unwrap(t)
        }
    }

    fun stop() {
        val clazz = findApiClass() ?: return
        runCatching { ensureSuccess(invoke(clazz, envelope("stopXray", JSONObject()))) }
        runCatching { clazz.methods.firstOrNull { it.name.equals("resetDNS", true) && it.parameterCount == 0 }?.invoke(null) }
        running.set(false)
    }

    fun queryStats(): Pair<Long, Long> = runCatching {
        val c = (URL("http://127.0.0.1:${AppConfig.METRICS_PORT}/debug/vars").openConnection() as HttpURLConnection).apply {
            connectTimeout = 700; readTimeout = 700
        }
        val json = c.inputStream.bufferedReader().use { JSONObject(it.readText()) }
        var up = 0L; var down = 0L
        fun walk(value: Any?, key: String = "") {
            when (value) {
                is JSONObject -> value.keys().forEach { k -> walk(value.opt(k), k) }
                is Number -> when {
                    key.contains("uplink", true) || key.contains("upload", true) -> up += value.toLong()
                    key.contains("downlink", true) || key.contains("download", true) -> down += value.toLong()
                }
            }
        }
        walk(json)
        up to down
    }.getOrDefault(0L to 0L)

    private fun registerSocketProtection(clazz: Class<*>, service: VpnService) {
        val interfaceClass = runCatching { Class.forName("libXray.DialerController") }.getOrElse {
            clazz.classLoader.loadClass("libXray.DialerController")
        }
        val proxy = Proxy.newProxyInstance(interfaceClass.classLoader, arrayOf(interfaceClass)) { _, method, args ->
            when (method.name.lowercase()) {
                "protectfd" -> service.protect((args?.firstOrNull() as Number).toInt())
                "tostring" -> "StarlinkDialerController"
                else -> null
            }
        }
        controllerProxy = proxy
        invokeOptional(clazz, "registerDialerController", proxy)
        invokeOptional(clazz, "registerListenerController", proxy)
    }

    private fun invokeOptional(clazz: Class<*>, methodName: String, vararg args: Any?) {
        val method = clazz.methods.firstOrNull { it.name.equals(methodName, true) && it.parameterCount == args.size } ?: return
        method.invoke(null, *args)
    }

    private fun invoke(clazz: Class<*>, request: String): String {
        val method = clazz.methods.firstOrNull { it.name.equals("invoke", true) && it.parameterCount == 1 }
            ?: error("تابع Invoke در libXray پیدا نشد.")
        return method.invoke(null, request)?.toString().orEmpty()
    }

    private fun envelope(method: String, payload: JSONObject) = JSONObject()
        .put("apiVersion", 1).put("method", method).put("payload", payload).toString()

    private fun ensureSuccess(response: String) {
        val json = runCatching { JSONObject(response) }.getOrElse { error("پاسخ libXray معتبر نیست: ${response.take(180)}") }
        if (!json.optBoolean("success")) error(json.optString("error", "راه‌اندازی Xray ناموفق بود."))
    }

    private fun findApiClass(): Class<*>? {
        apiClass?.let { return it }
        val candidates = listOf("libXray.LibXray", "libxray.LibXray")
        for (name in candidates) runCatching { Class.forName(name) }.getOrNull()?.let { apiClass = it; return it }
        return null
    }

    private fun unwrap(t: Throwable): Throwable = t.cause ?: t
}
