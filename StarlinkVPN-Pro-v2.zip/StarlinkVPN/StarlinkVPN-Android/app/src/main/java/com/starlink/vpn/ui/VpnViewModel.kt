package com.starlink.vpn.ui

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.starlink.vpn.AppConfig
import com.starlink.vpn.core.ConnectionState
import com.starlink.vpn.core.StarlinkVpnService
import com.starlink.vpn.model.*
import com.starlink.vpn.net.PanelApi
import com.starlink.vpn.net.SubscriptionParser
import com.starlink.vpn.net.XrayConfigBuilder
import com.starlink.vpn.store.LocalStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

class VpnViewModel(app: Application) : AndroidViewModel(app) {
    val servers = MutableStateFlow<List<ServerConfig>>(emptyList())
    val selected = MutableStateFlow<ServerConfig?>(null)
    val status = ConnectionState.status
    val error = ConnectionState.error
    val traffic = ConnectionState.traffic
    val connectedSince = ConnectionState.connectedSince
    val panelConfig = MutableStateFlow<PanelConfig?>(null)
    val pendingOrder = MutableStateFlow<PendingOrder?>(null)
    val orderStatus = MutableStateFlow<OrderStatus?>(null)
    val busy = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)

    private val store = LocalStore(app)
    private val panel = PanelApi(AppConfig.PANEL_BASE_URL)
    private var pollingJob: Job? = null

    init {
        pendingOrder.value = store.pendingOrder()
        refreshPanel()
        store.subscriptionUrl?.let(::loadSubscription)
        pendingOrder.value?.let { startOrderPolling(it) }
    }

    fun refreshPanel() = viewModelScope.launch(Dispatchers.IO) {
        runCatching { panel.getConfig() }
            .onSuccess { panelConfig.value = it }
            .onFailure { message.value = "اتصال به پنل مدیریت برقرار نشد: ${it.message}" }
    }

    fun clearMessage() { message.value = null }
    fun select(server: ServerConfig) { selected.value = server; store.selectedServerUri = server.rawUri }
    fun prepare(): Intent? = VpnService.prepare(getApplication())

    fun connect() {
        val server = selected.value ?: return ConnectionState.onError("ابتدا یک سرور انتخاب کنید.")
        ConnectionState.onConnecting()
        val intent = Intent(getApplication(), StarlinkVpnService::class.java)
            .setAction(StarlinkVpnService.ACTION_CONNECT)
            .putExtra(StarlinkVpnService.EXTRA_CONFIG_JSON, XrayConfigBuilder.build(server))
        ContextCompat.startForegroundService(getApplication(), intent)
    }

    fun disconnect() {
        getApplication<Application>().startService(
            Intent(getApplication(), StarlinkVpnService::class.java).setAction(StarlinkVpnService.ACTION_DISCONNECT)
        )
    }

    fun loadSubscription(url: String) = viewModelScope.launch(Dispatchers.IO) {
        busy.value = true
        runCatching {
            val body = panel.downloadText(url)
            val list = SubscriptionParser.parseSubscriptionContent(body)
            if (list.isEmpty()) error("هیچ سرور پشتیبانی‌شده‌ای داخل اشتراک نبود.")
            list
        }.onSuccess { list ->
            servers.value = list
            val saved = store.selectedServerUri
            selected.value = list.firstOrNull { it.rawUri == saved } ?: list.firstOrNull()
            store.subscriptionUrl = url
            message.value = "سرویس با موفقیت دریافت شد."
            pingServers()
        }.onFailure { ConnectionState.onError("دریافت اشتراک ناموفق بود: ${it.message}") }
        busy.value = false
    }

    fun submitReceipt(plan: Plan, contact: String, uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        if (contact.trim().length < 3) { message.value = "شماره یا شناسه تماس را وارد کنید."; return@launch }
        busy.value = true
        runCatching {
            val resolver = getApplication<Application>().contentResolver
            val mime = resolver.getType(uri) ?: "image/jpeg"
            if (mime !in setOf("image/jpeg", "image/png", "image/webp")) error("فرمت فیش باید JPG، PNG یا WEBP باشد.")
            val bytes = resolver.openInputStream(uri)?.use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                var total = 0
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    total += read
                    if (total > 5 * 1024 * 1024) error("حجم فیش بیشتر از ۵ مگابایت است.")
                    output.write(buffer, 0, read)
                }
                output.toByteArray()
            } ?: error("فایل فیش خوانده نشد.")
            panel.submitReceipt(plan.id, contact.trim(), bytes, "receipt.${mime.substringAfter('/')}", mime)
        }.onSuccess { submission ->
            store.contact = contact.trim()
            val order = PendingOrder(submission.trackCode, submission.orderToken, plan.title)
            store.savePending(order)
            pendingOrder.value = order
            orderStatus.value = OrderStatus(true, "pending")
            message.value = "فیش ثبت شد. کد رهگیری: ${submission.trackCode}"
            startOrderPolling(order)
        }.onFailure { message.value = it.message ?: "ارسال فیش ناموفق بود." }
        busy.value = false
    }

    fun refreshOrder() { pendingOrder.value?.let { checkOrder(it, true) } }

    private fun startOrderPolling(order: PendingOrder) {
        pollingJob?.cancel()
        pollingJob = viewModelScope.launch(Dispatchers.IO) {
            while (true) {
                val terminal = checkOrderNow(order)
                if (terminal) break
                delay((panelConfig.value?.pollSeconds ?: 8).coerceIn(5, 60) * 1000L)
            }
        }
    }

    private fun checkOrder(order: PendingOrder, showResult: Boolean) = viewModelScope.launch(Dispatchers.IO) {
        val result = runCatching { panel.orderStatus(order.trackCode, order.orderToken) }
        result.onSuccess { state ->
            handleOrderState(state)
            if (showResult && state.status == "pending") message.value = "فیش هنوز در انتظار بررسی است."
        }.onFailure { if (showResult) message.value = it.message }
    }

    private suspend fun checkOrderNow(order: PendingOrder): Boolean {
        val state = runCatching { panel.orderStatus(order.trackCode, order.orderToken) }.getOrNull() ?: return false
        handleOrderState(state)
        return state.status == "approved" || state.status == "rejected"
    }

    private fun handleOrderState(state: OrderStatus) {
        orderStatus.value = state
        when (state.status) {
            "approved" -> state.subUrl?.let { url ->
                store.subscriptionUrl = url
                store.savePending(null)
                pendingOrder.value = null
                message.value = "سرویس تأیید و داخل برنامه فعال شد."
                loadSubscription(url)
            }
            "rejected" -> message.value = state.note ?: "فیش توسط مدیریت رد شد."
        }
    }

    fun pingServers() = viewModelScope.launch(Dispatchers.IO) {
        val current = servers.value
        if (current.isEmpty()) return@launch
        val updated = current.map { server ->
            val start = System.nanoTime()
            val ping = runCatching {
                Socket().use { it.connect(InetSocketAddress(server.address, server.port), 2200) }
                ((System.nanoTime() - start) / 1_000_000).toInt()
            }.getOrDefault(-1)
            server.copy(pingMs = ping)
        }
        servers.value = updated
        selected.value?.let { selectedServer -> selected.value = updated.firstOrNull { it.id == selectedServer.id } ?: selectedServer }
    }

    fun currentContact(): String = store.contact
}
