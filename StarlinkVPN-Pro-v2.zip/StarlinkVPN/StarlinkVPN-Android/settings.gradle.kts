pluginManagement{repositories{google();mavenCentral();gradlePluginPortal()}}
dependencyResolutionManagement{repositories{google();mavenCentral()}}
rootProject.name="StarlinkVPN";include(":app")
