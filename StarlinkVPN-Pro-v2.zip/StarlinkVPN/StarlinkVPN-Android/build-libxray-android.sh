#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
WORK="${TMPDIR:-/tmp}/starlink-libxray-android"
rm -rf "$WORK"
git clone --depth 1 --branch v26.7.11 https://github.com/XTLS/libXray.git "$WORK"
cd "$WORK"
python3 build/main.py android
AAR="$(find . -type f -name '*.aar' | head -1)"
[ -n "$AAR" ] || { echo 'فایل AAR ساخته نشد'; exit 1; }
mkdir -p "$ROOT/app/libs"
cp "$AAR" "$ROOT/app/libs/libXray.aar"
echo "هسته آماده شد: $ROOT/app/libs/libXray.aar"
