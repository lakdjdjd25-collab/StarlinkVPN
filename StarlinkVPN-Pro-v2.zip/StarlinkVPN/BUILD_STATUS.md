# وضعیت تحویل Starlink VPN

تاریخ بسته: 2026-07-22

## اعتبارسنجی انجام‌شده

- تمام فایل‌های PHP با PHP 8.4 از نظر Syntax بررسی شدند.
- تمام فایل‌های Swift با Swift 6.2 از نظر Syntax parse شدند.
- تمام plist، XML، JSON و YAMLها parse شدند.
- تمام اسکریپت‌های Shell با `bash -n` بررسی شدند.
- Kotlin parser خطای نحوی گزارش نکرد؛ Type-check کامل Android بدون Android SDK و dependencyها در این محیط قابل اجرا نبود.
- `StarlinkPanel/config.php` با نسخه اولیه مقایسه و بدون تغییر تأیید شد.

## مواردی که در محیط تحویل اجرا نشدند

- اتصال واقعی به پنل پاسارگاد با اطلاعات خصوصی
- ساخت AAR رسمی libXray
- بیلد APK با Android SDK
- ساخت Xcode Project و IPA روی macOS
- امضای APK/IPA
- تست Network Extension روی iPhone واقعی

## معیار آماده‌بودن Production

برای انتشار واقعی، موارد زیر باید سبز شوند:

1. API روی Railway/VPS/هاست API-capable مستقر شود.
2. Health endpoint پاسخ `ok=true` بدهد.
3. یک سفارش آزمایشی تا دریافت Subscription پاسارگاد تکمیل شود.
4. GitHub Action خروجی APK بسازد.
5. Android روی حداقل دو نسخه سیستم‌عامل تست شود.
6. iOS با Network Extension entitlement روی دستگاه واقعی تست شود.
7. کلیدهای Release و Privacy Policy برای فروشگاه‌ها آماده شوند.
