import Foundation
import Darwin

enum LibXrayBridge {
    typealias InvokeFunction = @convention(c) (UnsafeMutablePointer<CChar>?) -> UnsafeMutablePointer<CChar>?
    typealias FreeFunction = @convention(c) (UnsafeMutablePointer<CChar>?) -> Void

    static var isAvailable: Bool { symbol("CGoInvoke") != nil && symbol("CGoFree") != nil }

    static func invoke(method: String, payload: [String: Any]) throws -> [String: Any] {
        guard let invokePtr = symbol("CGoInvoke"), let freePtr = symbol("CGoFree") else { throw BridgeError.missingFramework }
        let invoke = unsafeBitCast(invokePtr, to: InvokeFunction.self)
        let freeResult = unsafeBitCast(freePtr, to: FreeFunction.self)
        let request: [String: Any] = ["apiVersion": 1, "method": method, "payload": payload]
        let data = try JSONSerialization.data(withJSONObject: request)
        let requestString = String(decoding: data, as: UTF8.self)
        guard let input = strdup(requestString) else { throw BridgeError.invalidResponse }
        defer { Darwin.free(input) }
        guard let output = invoke(input) else { throw BridgeError.invalidResponse }
        defer { freeResult(output) }
        let outputString = String(cString: output)
        guard let responseData = outputString.data(using: .utf8), let response = try JSONSerialization.jsonObject(with: responseData) as? [String: Any] else { throw BridgeError.invalidResponse }
        guard response["success"] as? Bool == true else { throw BridgeError.xray(response["error"] as? String ?? "خطای libXray") }
        return response
    }

    private static func symbol(_ name: String) -> UnsafeMutableRawPointer? { dlsym(UnsafeMutableRawPointer(bitPattern: -2), name) }
}

enum BridgeError: LocalizedError {
    case missingFramework, invalidResponse, xray(String)
    var errorDescription: String? {
        switch self {
        case .missingFramework: return "فریم‌ورک رسمی LibXray.xcframework به پروژه اضافه نشده است."
        case .invalidResponse: return "پاسخ هسته Xray معتبر نیست."
        case .xray(let message): return message
        }
    }
}
