#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
WORK="${TMPDIR:-/tmp}/starlink-libxray-ios"
rm -rf "$WORK"
git clone --depth 1 --branch v26.7.11 https://github.com/XTLS/libXray.git "$WORK"
cd "$WORK"
python3 build/main.py apple go
FOUND="$(find . -type d -name 'LibXray.xcframework' | head -1)"
[ -n "$FOUND" ] || { echo 'LibXray.xcframework ساخته نشد'; exit 1; }
rm -rf "$ROOT/Frameworks/LibXray.xcframework"
cp -R "$FOUND" "$ROOT/Frameworks/LibXray.xcframework"
echo "LibXray.xcframework آماده شد. اکنون: brew install xcodegen && xcodegen generate"
