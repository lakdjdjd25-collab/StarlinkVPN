# StarlinkVPN iOS

نسخه iPhone با SwiftUI و Packet Tunnel Extension واقعی پیاده‌سازی شده و جریان خرید/فیش/اشتراک آن با Android هماهنگ است.

## فایل‌های اصلی

- `HomeView.swift` — رابط کاربری تیره و صفحات سرورها/خرید
- `VPNViewModel.swift` — سفارش، Polling، اشتراک، پینگ و وضعیت اتصال
- `VPNManager.swift` — مدیریت `NETunnelProviderManager`
- `PacketTunnel/PacketTunnelProvider.swift` — تونل واقعی iOS
- `LibXrayBridge.swift` — پل C API رسمی libXray
- `project.yml` — تولید پروژه Xcode با XcodeGen
- `build-libxray-ios.sh` — ساخت `LibXray.xcframework`

## بیلد

```bash
./build-libxray-ios.sh
brew install xcodegen
xcodegen generate
open StarlinkVPN.xcodeproj
```

سپس Team، Bundle ID و مجوز Network Extension را در Xcode تنظیم کنید.

بدون `LibXray.xcframework` برنامه کامپایل نهایی/اتصال واقعی نخواهد داشت. این باینری عمداً از مخزن رسمی XTLS/libXray ساخته می‌شود.
