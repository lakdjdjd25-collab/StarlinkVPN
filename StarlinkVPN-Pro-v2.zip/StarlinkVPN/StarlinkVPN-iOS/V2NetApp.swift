import SwiftUI

@main
struct StarlinkVPNApp: App {
    @StateObject private var vpn = VPNViewModel()
    var body: some Scene { WindowGroup { HomeView().environmentObject(vpn).preferredColorScheme(.dark) } }
}
