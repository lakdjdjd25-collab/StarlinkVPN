import Foundation

struct PanelAPI {
    private let baseURL = AppConfig.panelBaseURL
    private let decoder = JSONDecoder()

    func config() async throws -> PanelConfig {
        try await get(path: "/api.php?action=config", as: PanelConfig.self)
    }

    func orderStatus(_ order: PendingOrder) async throws -> OrderStatusResponse {
        var components = URLComponents(url: baseURL.appendingPathComponent("api.php"), resolvingAgainstBaseURL: false)!
        components.queryItems = [
            URLQueryItem(name: "action", value: "order_status"),
            URLQueryItem(name: "track", value: order.trackCode),
            URLQueryItem(name: "token", value: order.orderToken)
        ]
        return try await request(URLRequest(url: components.url!), as: OrderStatusResponse.self)
    }

    func submitReceipt(plan: Plan, contact: String, imageData: Data, mimeType: String) async throws -> OrderSubmission {
        let boundary = "Starlink-\(UUID().uuidString)"
        var request = URLRequest(url: baseURL.appendingPathComponent("api.php").appending(queryItems: [URLQueryItem(name: "action", value: "submit_receipt")]))
        request.httpMethod = "POST"
        request.timeoutInterval = 45
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.setValue("ios", forHTTPHeaderField: "X-Client-Platform")
        var body = Data()
        func append(_ string: String) { body.append(string.data(using: .utf8)!) }
        func field(_ name: String, _ value: String) {
            append("--\(boundary)\r\nContent-Disposition: form-data; name=\"\(name)\"\r\n\r\n\(value)\r\n")
        }
        field("plan_id", plan.id)
        field("contact", contact)
        let ext = mimeType == "image/png" ? "png" : mimeType == "image/webp" ? "webp" : "jpg"
        append("--\(boundary)\r\nContent-Disposition: form-data; name=\"receipt\"; filename=\"receipt.\(ext)\"\r\nContent-Type: \(mimeType)\r\n\r\n")
        body.append(imageData)
        append("\r\n--\(boundary)--\r\n")
        request.httpBody = body
        return try await self.request(request, as: OrderSubmission.self)
    }

    func subscription(_ url: URL) async throws -> String {
        var request = URLRequest(url: url)
        request.timeoutInterval = 30
        request.setValue("StarlinkVPN-iOS/2.0", forHTTPHeaderField: "User-Agent")
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response: response, data: data)
        guard let text = String(data: data, encoding: .utf8) else { throw APIError.message("متن اشتراک خوانده نشد.") }
        return text
    }

    private func get<T: Decodable>(path: String, as type: T.Type) async throws -> T {
        try await request(URLRequest(url: URL(string: path, relativeTo: baseURL)!), as: type)
    }

    private func request<T: Decodable>(_ request: URLRequest, as type: T.Type) async throws -> T {
        var request = request
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("ios", forHTTPHeaderField: "X-Client-Platform")
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response: response, data: data)
        do { return try decoder.decode(T.self, from: data) }
        catch { throw APIError.message("پاسخ پنل قابل خواندن نیست.") }
    }

    private func validate(response: URLResponse, data: Data) throws {
        guard let http = response as? HTTPURLResponse else { throw APIError.message("پاسخ شبکه نامعتبر است.") }
        guard 200..<300 ~= http.statusCode else {
            let json = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            throw APIError.message((json?["error"] as? String) ?? "خطای پنل (\(http.statusCode))")
        }
    }
}

enum APIError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let value) = self { return value }; return nil }
}

private extension URL {
    func appending(queryItems: [URLQueryItem]) -> URL {
        var c = URLComponents(url: self, resolvingAgainstBaseURL: false)!
        c.queryItems = queryItems
        return c.url!
    }
}
