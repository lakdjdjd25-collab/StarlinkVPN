import Foundation
import SwiftUI
import Combine
import Network
import NetworkExtension

@MainActor
final class VPNViewModel: ObservableObject {
    @Published var state: VPNState = .disconnected
    @Published var elapsed: TimeInterval = 0
    @Published var uploadBytesPerSecond: Int64 = 0
    @Published var downloadBytesPerSecond: Int64 = 0
    @Published var servers: [VPNServer] = []
    @Published var selectedServer: VPNServer?
    @Published var panelConfig: PanelConfig?
    @Published var pendingOrder: PendingOrder?
    @Published var orderStatus: OrderStatusResponse?
    @Published var message: String?
    @Published var busy = false

    private let api = PanelAPI()
    private let store = LocalStore()
    private let vpnManager = VPNManager()
    private var cancellables = Set<AnyCancellable>()
    private var connectedAt: Date?
    private var timerTask: Task<Void, Never>?
    private var pollingTask: Task<Void, Never>?
    private var previousUploadBytes: Int64 = 0
    private var previousDownloadBytes: Int64 = 0

    init() {
        pendingOrder = store.pendingOrder
        vpnManager.$status
            .receive(on: RunLoop.main)
            .sink { [weak self] status in self?.apply(status: status) }
            .store(in: &cancellables)
        Task {
            do { try await vpnManager.prepare() } catch { message = error.localizedDescription }
            await refreshPanel()
            if let url = store.subscriptionURL { await loadSubscription(url) }
            if let order = pendingOrder { startPolling(order) }
        }
    }

    var elapsedText: String {
        let seconds = Int(elapsed)
        return String(format: "%02d:%02d:%02d", seconds / 3600, (seconds % 3600) / 60, seconds % 60)
    }

    var uploadText: String { Self.formatSpeed(uploadBytesPerSecond) }
    var downloadText: String { Self.formatSpeed(downloadBytesPerSecond) }
    var contact: String { store.contact }

    func clearMessage() { message = nil }

    func refreshPanel() async {
        do { panelConfig = try await api.config() }
        catch { message = "اتصال به پنل مدیریت برقرار نشد: \(error.localizedDescription)" }
    }

    func select(_ server: VPNServer) {
        selectedServer = server
        store.selectedServerURI = server.rawURI
    }

    func toggleConnection() {
        switch state {
        case .connected, .connecting: vpnManager.disconnect()
        case .disconnected, .error: Task { await connect() }
        }
    }

    func connect() async {
        guard let server = selectedServer else { state = .error("ابتدا یک سرور انتخاب کنید."); return }
        state = .connecting
        do { try await vpnManager.connect(server: server) }
        catch { state = .error(error.localizedDescription) }
    }

    func submitReceipt(plan: Plan, contact: String, imageData: Data, mimeType: String) async {
        guard contact.trimmingCharacters(in: .whitespacesAndNewlines).count >= 3 else { message = "شماره یا شناسه تماس را وارد کنید."; return }
        guard imageData.count <= 5 * 1024 * 1024 else { message = "حجم فیش بیشتر از ۵ مگابایت است."; return }
        busy = true
        defer { busy = false }
        do {
            let result = try await api.submitReceipt(plan: plan, contact: contact, imageData: imageData, mimeType: mimeType)
            let order = PendingOrder(trackCode: result.track_code, orderToken: result.order_token, planTitle: plan.title)
            store.contact = contact
            store.pendingOrder = order
            pendingOrder = order
            orderStatus = OrderStatusResponse(ok: true, status: "pending", sub_url: nil, note: nil, vpn_username: nil)
            message = "فیش ثبت شد. کد رهگیری: \(result.track_code)"
            startPolling(order)
        } catch { message = error.localizedDescription }
    }

    func refreshOrder() async {
        guard let order = pendingOrder else { return }
        do {
            let status = try await api.orderStatus(order)
            await handleOrderStatus(status)
            if status.status == "pending" { message = "فیش هنوز در انتظار بررسی است." }
        } catch { message = error.localizedDescription }
    }

    func pingServers() async {
        let current = servers
        var results: [VPNServer] = []
        for var server in current {
            server.pingMs = await tcpPing(host: server.address, port: server.port)
            results.append(server)
        }
        servers = results
        if let selected = selectedServer { selectedServer = results.first(where: { $0.id == selected.id }) ?? selected }
    }

    private func loadSubscription(_ url: URL) async {
        busy = true
        defer { busy = false }
        do {
            let raw = try await api.subscription(url)
            let parsed = SubscriptionParser.parse(raw)
            guard !parsed.isEmpty else { throw APIError.message("هیچ سرور پشتیبانی‌شده‌ای داخل اشتراک نبود.") }
            servers = parsed
            selectedServer = parsed.first(where: { $0.rawURI == store.selectedServerURI }) ?? parsed.first
            store.subscriptionURL = url
            Task { await pingServers() }
        } catch { state = .error("دریافت اشتراک ناموفق بود: \(error.localizedDescription)") }
    }

    private func startPolling(_ order: PendingOrder) {
        pollingTask?.cancel()
        pollingTask = Task {
            while !Task.isCancelled {
                do {
                    let status = try await api.orderStatus(order)
                    await handleOrderStatus(status)
                    if status.status == "approved" || status.status == "rejected" { return }
                } catch { }
                try? await Task.sleep(for: .seconds(Double(max(5, panelConfig?.poll_seconds ?? 8))))
            }
        }
    }

    private func handleOrderStatus(_ status: OrderStatusResponse) async {
        orderStatus = status
        if status.status == "approved", let string = status.sub_url, let url = URL(string: string) {
            store.subscriptionURL = url
            store.pendingOrder = nil
            pendingOrder = nil
            message = "سرویس تأیید و داخل برنامه فعال شد."
            await loadSubscription(url)
        } else if status.status == "rejected" {
            message = status.note ?? "فیش توسط مدیریت رد شد."
        }
    }

    private func apply(status: NEVPNStatus) {
        switch status {
        case .connecting, .reasserting, .disconnecting: state = .connecting
        case .connected:
            state = .connected
            connectedAt = connectedAt ?? Date()
            startTimer()
        case .disconnected, .invalid:
            state = .disconnected
            connectedAt = nil
            stopTimer()
        @unknown default: state = .disconnected
        }
    }

    private func startTimer() {
        timerTask?.cancel()
        timerTask = Task {
            while !Task.isCancelled {
                if let connectedAt { elapsed = Date().timeIntervalSince(connectedAt) }
                await updateMetrics()
                try? await Task.sleep(for: .seconds(1))
            }
        }
    }

    private func stopTimer() {
        timerTask?.cancel(); timerTask = nil
        elapsed = 0
        uploadBytesPerSecond = 0
        downloadBytesPerSecond = 0
        previousUploadBytes = 0
        previousDownloadBytes = 0
    }

    private func updateMetrics() async {
        guard let url = URL(string: "http://127.0.0.1:\(AppConfig.metricsPort)/debug/vars") else { return }
        var request = URLRequest(url: url); request.timeoutInterval = 0.7
        guard let (data, _) = try? await URLSession.shared.data(for: request),
              let object = try? JSONSerialization.jsonObject(with: data) else { return }
        var up: Int64 = 0, down: Int64 = 0
        func walk(_ value: Any, key: String = "") {
            if let dict = value as? [String: Any] { for (k, v) in dict { walk(v, key: k) } }
            else if let n = value as? NSNumber {
                if key.localizedCaseInsensitiveContains("uplink") || key.localizedCaseInsensitiveContains("upload") { up += n.int64Value }
                if key.localizedCaseInsensitiveContains("downlink") || key.localizedCaseInsensitiveContains("download") { down += n.int64Value }
            }
        }
        walk(object)
        uploadBytesPerSecond = max(0, up - previousUploadBytes)
        downloadBytesPerSecond = max(0, down - previousDownloadBytes)
        previousUploadBytes = up
        previousDownloadBytes = down
    }

    private func tcpPing(host: String, port: Int) async -> Int {
        guard let endpointPort = NWEndpoint.Port(rawValue: UInt16(clamping: port)) else { return -1 }
        return await withCheckedContinuation { continuation in
            let start = DispatchTime.now()
            let connection = NWConnection(host: NWEndpoint.Host(host), port: endpointPort, using: .tcp)
            let gate = ResumeGate()

            func finish(_ result: Int) {
                gate.runOnce {
                    connection.cancel()
                    continuation.resume(returning: result)
                }
            }

            connection.stateUpdateHandler = { state in
                switch state {
                case .ready:
                    let ms = Int((DispatchTime.now().uptimeNanoseconds - start.uptimeNanoseconds) / 1_000_000)
                    finish(ms)
                case .failed, .cancelled:
                    finish(-1)
                default:
                    break
                }
            }
            connection.start(queue: .global(qos: .utility))
            DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 2.2) {
                finish(-1)
            }
        }
    }

    private static func formatSpeed(_ bytes: Int64) -> String {
        if bytes >= 1_048_576 { return String(format: "%.1f MB/s", Double(bytes) / 1_048_576) }
        if bytes >= 1024 { return String(format: "%.0f KB/s", Double(bytes) / 1024) }
        return "\(bytes) B/s"
    }
}

private final class ResumeGate: @unchecked Sendable {
    private let lock = NSLock()
    private var completed = false

    func runOnce(_ action: () -> Void) {
        lock.lock()
        guard !completed else {
            lock.unlock()
            return
        }
        completed = true
        lock.unlock()
        action()
    }
}
