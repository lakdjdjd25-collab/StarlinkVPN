//
//  Theme.swift
//  V2Net
//
//  Central place for all colors / fonts so the design stays
//  pixel-consistent with the Android version.
//

import SwiftUI

enum Theme {
    // MARK: Background
    /// Main dark navy background
    static let background      = Color(hex: 0x24243A)
    /// Slightly lighter surface used for cards
    static let surface        = Color.white.opacity(0.04)
    static let surfaceBorder  = Color.white.opacity(0.14)

    // MARK: Text
    static let textPrimary    = Color.white
    static let textSecondary  = Color.white.opacity(0.55)

    // MARK: Accents
    static let premiumYellow  = Color(hex: 0xF2B90D)
    static let telegramBlue   = Color(hex: 0x2AA6E8)
    static let remainingGreen = Color(hex: 0x7ED321)
    static let connectedGreen = Color(hex: 0x4CD964)
    static let errorRed       = Color(hex: 0xE0403F)
    static let badgeRed       = Color(hex: 0xE0302F)

    // MARK: Power button rings
    static let ringOuter      = Color.white.opacity(0.03)
    static let ringMiddle     = Color.white.opacity(0.05)
    static let ringInner      = Color.white.opacity(0.08)
}

extension Color {
    /// Convenience init: Color(hex: 0x24243A)
    init(hex: UInt32, opacity: Double = 1) {
        self.init(
            .sRGB,
            red:     Double((hex >> 16) & 0xFF) / 255,
            green:   Double((hex >> 8)  & 0xFF) / 255,
            blue:    Double(hex & 0xFF) / 255,
            opacity: opacity
        )
    }
}
