import Foundation
import NetworkExtension

@MainActor
final class VPNManager: ObservableObject {
    @Published private(set) var status: NEVPNStatus = .invalid
    private var manager: NETunnelProviderManager?
    private var observer: NSObjectProtocol?

    init() {
        observer = NotificationCenter.default.addObserver(forName: .NEVPNStatusDidChange, object: nil, queue: .main) { [weak self] _ in
            Task { @MainActor in self?.status = self?.manager?.connection.status ?? .invalid }
        }
    }

    deinit { if let observer { NotificationCenter.default.removeObserver(observer) } }

    func prepare() async throws {
        let managers = try await NETunnelProviderManager.loadAllFromPreferences()
        manager = managers.first ?? NETunnelProviderManager()
        status = manager?.connection.status ?? .invalid
    }

    func connect(server: VPNServer) async throws {
        if manager == nil { try await prepare() }
        let configJSON = try XrayConfigBuilder.build(server: server)
        let proto = NETunnelProviderProtocol()
        proto.providerBundleIdentifier = AppConfig.providerBundleIdentifier
        proto.serverAddress = server.address
        proto.providerConfiguration = ["xrayConfig": configJSON, "serverName": server.name]
        manager?.protocolConfiguration = proto
        manager?.localizedDescription = AppConfig.brand
        manager?.isEnabled = true
        try await manager?.saveToPreferences()
        try await manager?.loadFromPreferences()
        try manager?.connection.startVPNTunnel()
    }

    func disconnect() { manager?.connection.stopVPNTunnel() }
}
