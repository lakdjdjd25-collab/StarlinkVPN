import Foundation

enum SubscriptionParser {
    static func parse(_ raw: String) -> [VPNServer] {
        let text = decodeBase64(raw.trimmingCharacters(in: .whitespacesAndNewlines)) ?? raw
        return text.split(whereSeparator: \.isNewline).compactMap { parseURI(String($0).trimmingCharacters(in: .whitespacesAndNewlines)) }
    }

    static func parseURI(_ raw: String) -> VPNServer? {
        guard let scheme = URLComponents(string: raw)?.scheme?.lowercased(), ["vless","vmess","trojan","ss"].contains(scheme) else { return nil }
        if scheme == "vmess" {
            guard let data = Data(base64Encoded: padded(String(raw.dropFirst(8))), options: .ignoreUnknownCharacters),
                  let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let address = object["add"] as? String else { return nil }
            let port = Int(String(describing: object["port"] ?? "443")) ?? 443
            let name = (object["ps"] as? String)?.removingPercentEncoding ?? address
            return VPNServer(id: stable(raw), name: name, protocolName: scheme, address: address, port: port, rawURI: raw)
        }
        if scheme == "ss", !raw.dropFirst(5).contains("@") {
            let encoded = String(raw.dropFirst(5)).components(separatedBy: "#")[0]
            guard let decoded = decodeBase64(encoded), let at = decoded.lastIndex(of: "@") else { return nil }
            let hostPort = decoded[decoded.index(after: at)...]
            let parts = hostPort.split(separator: ":")
            guard parts.count == 2, let port = Int(parts[1]) else { return nil }
            let name = raw.components(separatedBy: "#").dropFirst().first?.removingPercentEncoding ?? String(parts[0])
            return VPNServer(id: stable(raw), name: name, protocolName: scheme, address: String(parts[0]), port: port, rawURI: raw)
        }
        guard let c = URLComponents(string: raw), let address = c.host else { return nil }
        let name = c.fragment?.removingPercentEncoding ?? address
        return VPNServer(id: stable(raw), name: name, protocolName: scheme == "ss" ? "shadowsocks" : scheme, address: address, port: c.port ?? 443, rawURI: raw)
    }

    private static func decodeBase64(_ value: String) -> String? {
        guard let data = Data(base64Encoded: padded(value.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")), options: .ignoreUnknownCharacters),
              let text = String(data: data, encoding: .utf8), text.contains("://") || text.contains("@") else { return nil }
        return text
    }
    private static func padded(_ value: String) -> String { value + String(repeating: "=", count: (4 - value.count % 4) % 4) }
    private static func stable(_ value: String) -> String { String(value.hashValue, radix: 16) }
}
