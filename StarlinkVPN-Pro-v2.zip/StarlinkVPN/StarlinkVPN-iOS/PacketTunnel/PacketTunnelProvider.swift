import Foundation
import NetworkExtension
import Darwin

final class PacketTunnelProvider: NEPacketTunnelProvider {
    private let coreQueue = DispatchQueue(label: "com.starlink.vpn.xray", qos: .userInitiated)
    private var started = false

    override func startTunnel(options: [String : NSObject]? = nil, completionHandler: @escaping (Error?) -> Void) {
        guard let proto = protocolConfiguration as? NETunnelProviderProtocol,
              let baseConfig = proto.providerConfiguration?["xrayConfig"] as? String else {
            completionHandler(TunnelError.missingConfiguration)
            return
        }

        let settings = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: proto.serverAddress ?? "Starlink VPN")
        let ipv4 = NEIPv4Settings(addresses: ["172.19.0.1"], subnetMasks: ["255.255.255.252"])
        ipv4.includedRoutes = [NEIPv4Route.default()]
        settings.ipv4Settings = ipv4
        let ipv6 = NEIPv6Settings(addresses: ["fd00:1:fd00:1::1"], networkPrefixLengths: [126])
        ipv6.includedRoutes = [NEIPv6Route.default()]
        settings.ipv6Settings = ipv6
        settings.dnsSettings = NEDNSSettings(servers: ["1.1.1.1", "8.8.8.8"])
        settings.mtu = 1500

        setTunnelNetworkSettings(settings) { [weak self] error in
            guard let self else { completionHandler(TunnelError.deallocated); return }
            if let error { completionHandler(error); return }
            guard LibXrayBridge.isAvailable else { completionHandler(BridgeError.missingFramework); return }
            guard let fd = self.findUtunFileDescriptor() else { completionHandler(TunnelError.utunNotFound); return }

            self.coreQueue.async {
                do {
                    let config = try self.attachTunFD(baseConfig, fd: fd)
                    let url = FileManager.default.temporaryDirectory.appendingPathComponent("starlink-xray-config.json")
                    try config.write(to: url, atomically: true, encoding: .utf8)
                    _ = try LibXrayBridge.invoke(method: "runXray", payload: ["configPath": url.path])
                    self.started = true
                    completionHandler(nil)
                } catch {
                    completionHandler(error)
                }
            }
        }
    }

    override func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {
        coreQueue.async {
            if self.started { _ = try? LibXrayBridge.invoke(method: "stopXray", payload: [:]) }
            self.started = false
            completionHandler()
        }
    }

    override func handleAppMessage(_ messageData: Data, completionHandler: ((Data?) -> Void)? = nil) {
        let payload: [String: Any] = ["running": started]
        completionHandler?(try? JSONSerialization.data(withJSONObject: payload))
    }

    private func attachTunFD(_ config: String, fd: Int32) throws -> String {
        guard var root = try JSONSerialization.jsonObject(with: Data(config.utf8)) as? [String: Any] else { throw TunnelError.invalidConfiguration }
        root["env"] = ["xray.tun.fd": String(fd)]
        return String(decoding: try JSONSerialization.data(withJSONObject: root), as: UTF8.self)
    }

    private func findUtunFileDescriptor() -> Int32? {
        let prefix = Array("utun".utf8)
        for fd in Int32(0)...Int32(1024) {
            var buffer = [CChar](repeating: 0, count: Int(IFNAMSIZ))
            var length = socklen_t(buffer.count)
            let result = getsockopt(fd, 2, 2, &buffer, &length)
            guard result == 0 else { continue }
            let bytes = buffer.prefix(Int(length)).map { UInt8(bitPattern: $0) }
            if bytes.starts(with: prefix) { return fd }
        }
        return nil
    }
}

enum TunnelError: LocalizedError {
    case missingConfiguration, utunNotFound, invalidConfiguration, deallocated
    var errorDescription: String? {
        switch self {
        case .missingConfiguration: return "کانفیگ تونل دریافت نشد."
        case .utunNotFound: return "فایل‌دسکریپتور تونل iOS پیدا نشد."
        case .invalidConfiguration: return "کانفیگ Xray نامعتبر است."
        case .deallocated: return "تونل پیش از شروع بسته شد."
        }
    }
}
