import Foundation

enum VPNState: Equatable { case disconnected, connecting, connected, error(String) }

struct VPNServer: Identifiable, Hashable, Codable {
    let id: String
    let name: String
    let protocolName: String
    let address: String
    let port: Int
    let rawURI: String
    var pingMs: Int = -1
}

struct Plan: Identifiable, Codable, Hashable {
    let id: String
    let title: String
    let days: Int
    let gb: Int
    let price: Int
}

struct CardInfo: Codable { let number: String; let holder: String }
struct PanelConfig: Codable {
    let ok: Bool
    let plans: [Plan]
    let card: CardInfo
    let brand: String
    let telegram: String
    let poll_seconds: Int
}
struct OrderSubmission: Codable { let ok: Bool; let track_code: String; let order_token: String; let status: String }
struct OrderStatusResponse: Codable {
    let ok: Bool
    let status: String
    let sub_url: String?
    let note: String?
    let vpn_username: String?
}
struct PendingOrder: Codable, Equatable { let trackCode: String; let orderToken: String; let planTitle: String }
