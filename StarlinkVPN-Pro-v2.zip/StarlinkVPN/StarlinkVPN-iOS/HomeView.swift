import SwiftUI
import PhotosUI

struct HomeView: View {
    @EnvironmentObject private var vpn: VPNViewModel
    @Environment(\.openURL) private var openURL
    @State private var showingServers = false
    @State private var showingPurchase = false

    var body: some View {
        ZStack {
            Theme.background.ignoresSafeArea()
            WorldMapBackground()
            VStack(spacing: 0) {
                topBar
                    .padding(.horizontal, 20)
                    .padding(.top, 8)

                VStack(spacing: 6) {
                    Text("Connecting Time").font(.system(size: 17)).foregroundStyle(Theme.textSecondary)
                    Text(vpn.elapsedText).font(.system(size: 52, weight: .medium)).monospacedDigit().foregroundStyle(Theme.textPrimary)
                }
                .padding(.top, 28)

                serverCard
                    .padding(.horizontal, 20)
                    .padding(.top, 24)

                HStack(spacing: 0) {
                    TrafficStat(title: "Upload", value: vpn.uploadText, icon: "arrow.up.right").frame(maxWidth: .infinity)
                    Rectangle().fill(Theme.surfaceBorder).frame(width: 1, height: 44)
                    TrafficStat(title: "Download", value: vpn.downloadText, icon: "arrow.down.left").frame(maxWidth: .infinity)
                }
                .padding(.horizontal, 40)
                .padding(.top, 20)

                if let order = vpn.pendingOrder {
                    Button { Task { await vpn.refreshOrder() } } label: {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("فیش \(order.planTitle)").font(.headline).foregroundStyle(.white)
                                Text("\(order.trackCode) · \(statusFA(vpn.orderStatus?.status ?? "pending"))").font(.caption).foregroundStyle(Theme.textSecondary)
                            }
                            Spacer()
                            Text("بررسی").foregroundStyle(Theme.premiumYellow)
                        }
                        .padding(12)
                        .background(RoundedRectangle(cornerRadius: 12).fill(Theme.premiumYellow.opacity(0.10)))
                    }
                    .buttonStyle(.plain)
                    .padding(.horizontal, 20)
                    .padding(.top, 14)
                }

                Spacer()
                PowerButton(state: vpn.state) { vpn.toggleConnection() }
                HStack(spacing: 6) {
                    Text(statusText)
                    Image(systemName: statusIcon)
                }
                .font(.system(size: 19, weight: .medium, design: .monospaced))
                .foregroundStyle(statusColor)
                .multilineTextAlignment(.center)
                .padding(.top, 16)

                Button("خرید یا تمدید سرویس") { showingPurchase = true }
                    .foregroundStyle(Theme.premiumYellow)
                    .padding(.top, 5)
                    .padding(.bottom, 18)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showingServers) { ServerListView().environmentObject(vpn) }
        .sheet(isPresented: $showingPurchase) { PurchaseView().environmentObject(vpn) }
        .alert("Starlink VPN", isPresented: Binding(get: { vpn.message != nil }, set: { if !$0 { vpn.clearMessage() } })) {
            Button("باشه") { vpn.clearMessage() }
        } message: { Text(vpn.message ?? "") }
    }

    private var topBar: some View {
        HStack {
            IconSquare(background: Theme.premiumYellow) { Image(systemName: "crown.fill").foregroundStyle(.white) }
                .onTapGesture { showingPurchase = true }
            IconSquare(background: Color.white.opacity(0.08)) { Image(systemName: "square.grid.3x3.fill").foregroundStyle(.white) }
                .onTapGesture { showingServers = true }
            Spacer()
            Text(AppConfig.brand).font(.system(size: 25, weight: .bold)).foregroundStyle(.white)
            Spacer()
            IconSquare(background: Color.white.opacity(0.08)) { Image(systemName: "arrow.clockwise").foregroundStyle(.white) }
                .onTapGesture { Task { await vpn.refreshPanel() } }
            IconSquare(background: Theme.telegramBlue) { Image(systemName: "paperplane.fill").foregroundStyle(.white) }
                .onTapGesture { openURL(AppConfig.telegramURL) }
        }
    }

    private var serverCard: some View {
        Button { showingServers = true } label: {
            HStack(spacing: 14) {
                Image(systemName: "chevron.left").foregroundStyle(.white.opacity(0.8))
                VStack(spacing: 3) {
                    Text(vpn.selectedServer?.name ?? "سروری انتخاب نشده").font(.system(size: 20, weight: .semibold)).foregroundStyle(.white).lineLimit(1)
                    if let server = vpn.selectedServer {
                        Text("\(server.protocolName.uppercased()) · \(server.pingMs >= 0 ? "\(server.pingMs) ms" : "در انتظار تست")")
                            .font(.system(size: 12)).foregroundStyle(Theme.textSecondary)
                    } else {
                        Text("برای انتخاب لمس کنید").font(.system(size: 12)).foregroundStyle(Theme.textSecondary)
                    }
                }
                .frame(maxWidth: .infinity)
                Circle().fill(vpn.selectedServer == nil ? Color.gray.opacity(0.3) : Theme.connectedGreen.opacity(0.2)).frame(width: 46, height: 46)
                    .overlay(Image(systemName: vpn.selectedServer == nil ? "questionmark" : "checkmark").foregroundStyle(.white))
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 13)
            .background(RoundedRectangle(cornerRadius: 14).fill(Theme.surface).overlay(RoundedRectangle(cornerRadius: 14).stroke(Theme.surfaceBorder, lineWidth: 1)))
        }
        .buttonStyle(.plain)
    }

    private var statusText: String {
        switch vpn.state {
        case .disconnected: return "Not Connected"
        case .connecting: return "Connecting..."
        case .connected: return "Connected"
        case .error(let message): return message
        }
    }
    private var statusColor: Color {
        switch vpn.state { case .connected: return Theme.connectedGreen; case .connecting: return Theme.premiumYellow; case .disconnected, .error: return Theme.errorRed }
    }
    private var statusIcon: String { if case .connected = vpn.state { return "checkmark.circle" }; return "nosign" }
}

private struct ServerListView: View {
    @EnvironmentObject var vpn: VPNViewModel
    @Environment(\.dismiss) var dismiss
    var body: some View {
        NavigationStack {
            ZStack {
                Theme.background.ignoresSafeArea()
                if vpn.servers.isEmpty {
                    Text("ابتدا سرویس بخرید یا منتظر تأیید فیش بمانید.").foregroundStyle(Theme.textSecondary).multilineTextAlignment(.center).padding()
                } else {
                    List(vpn.servers) { server in
                        Button {
                            vpn.select(server); dismiss()
                        } label: {
                            HStack {
                                Circle().fill(Color.white.opacity(0.08)).frame(width: 42, height: 42).overlay(Text(String(server.protocolName.prefix(1)).uppercased()).foregroundStyle(.white))
                                VStack(alignment: .leading) {
                                    Text(server.name).foregroundStyle(.white).fontWeight(.semibold)
                                    Text("\(server.address):\(server.port)").font(.caption).foregroundStyle(Theme.textSecondary)
                                }
                                Spacer()
                                Text(server.pingMs >= 0 ? "\(server.pingMs) ms" : "—").font(.caption).foregroundStyle(server.pingMs > 0 && server.pingMs < 250 ? Theme.connectedGreen : Theme.textSecondary)
                                if vpn.selectedServer?.id == server.id { Image(systemName: "checkmark.circle.fill").foregroundStyle(Theme.connectedGreen) }
                            }
                        }
                        .listRowBackground(Color.white.opacity(0.04))
                    }
                    .scrollContentBackground(.hidden)
                }
            }
            .navigationTitle("لیست سرورها")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("بستن") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) { Button("تست پینگ") { Task { await vpn.pingServers() } } }
            }
        }
        .preferredColorScheme(.dark)
    }
}

private struct PurchaseView: View {
    @EnvironmentObject var vpn: VPNViewModel
    @Environment(\.dismiss) var dismiss
    @State private var selectedPlan: Plan?
    @State private var contact = ""
    @State private var photoItem: PhotosPickerItem?
    @State private var imageData: Data?
    @State private var mimeType = "image/jpeg"

    var body: some View {
        NavigationStack {
            ZStack {
                Theme.background.ignoresSafeArea()
                if let config = vpn.panelConfig {
                    ScrollView {
                        VStack(spacing: 12) {
                            Text("انتخاب پلن").frame(maxWidth: .infinity, alignment: .leading).font(.headline).foregroundStyle(.white)
                            ForEach(config.plans) { plan in
                                Button { selectedPlan = plan } label: {
                                    HStack {
                                        Image(systemName: selectedPlan?.id == plan.id ? "largecircle.fill.circle" : "circle").foregroundStyle(Theme.premiumYellow)
                                        VStack(alignment: .leading) {
                                            Text(plan.title).foregroundStyle(.white).fontWeight(.bold)
                                            Text("\(plan.days) روز · \(plan.gb) گیگابایت").font(.caption).foregroundStyle(Theme.textSecondary)
                                        }
                                        Spacer()
                                        Text("\(plan.price.formatted()) تومان").foregroundStyle(Theme.premiumYellow).fontWeight(.bold)
                                    }
                                    .padding(15)
                                    .background(RoundedRectangle(cornerRadius: 13).fill(selectedPlan?.id == plan.id ? Theme.premiumYellow.opacity(0.14) : Color.white.opacity(0.04)))
                                }.buttonStyle(.plain)
                            }
                            VStack(alignment: .leading, spacing: 8) {
                                Text("واریز به کارت").font(.headline).foregroundStyle(.white)
                                Text(config.card.number).font(.title3).foregroundStyle(Theme.premiumYellow).textSelection(.enabled)
                                Text("به نام \(config.card.holder)").foregroundStyle(Theme.textSecondary)
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(16)
                            .background(RoundedRectangle(cornerRadius: 13).fill(Color.white.opacity(0.04)))

                            TextField("شماره تماس یا آیدی تلگرام", text: $contact)
                                .textInputAutocapitalization(.never)
                                .padding(14).background(RoundedRectangle(cornerRadius: 12).fill(Color.white.opacity(0.06))).foregroundStyle(.white)

                            PhotosPicker(selection: $photoItem, matching: .images) {
                                Label(imageData == nil ? "انتخاب تصویر فیش" : "فیش انتخاب شد", systemImage: imageData == nil ? "photo" : "checkmark.circle.fill")
                                    .frame(maxWidth: .infinity).padding(15).background(RoundedRectangle(cornerRadius: 12).stroke(Theme.surfaceBorder))
                            }
                            .onChange(of: photoItem) { item in
                                Task {
                                    imageData = try? await item?.loadTransferable(type: Data.self)
                                    if let data = imageData { mimeType = detectMime(data) }
                                }
                            }

                            Button {
                                guard let plan = selectedPlan, let imageData else { return }
                                Task { await vpn.submitReceipt(plan: plan, contact: contact, imageData: imageData, mimeType: mimeType) }
                            } label: {
                                Group { if vpn.busy { ProgressView().tint(.black) } else { Text("ارسال فیش برای تأیید").fontWeight(.bold) } }
                                    .frame(maxWidth: .infinity).padding(16)
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(Theme.premiumYellow)
                            .foregroundStyle(.black)
                            .disabled(vpn.busy || selectedPlan == nil || imageData == nil || contact.trimmingCharacters(in: .whitespaces).count < 3)

                            Text("پس از تأیید مدیر، لینک پاسارگاد خودکار داخل برنامه فعال می‌شود.").font(.caption).foregroundStyle(Theme.textSecondary).multilineTextAlignment(.center)
                        }
                        .padding(16)
                    }
                } else { ProgressView().tint(Theme.premiumYellow) }
            }
            .navigationTitle("خرید سرویس")
            .toolbar { ToolbarItem(placement: .topBarLeading) { Button("بستن") { dismiss() } } }
        }
        .onAppear { contact = vpn.contact; selectedPlan = vpn.panelConfig?.plans.first }
        .preferredColorScheme(.dark)
    }

    private func detectMime(_ data: Data) -> String {
        if data.starts(with: [0x89, 0x50, 0x4E, 0x47]) { return "image/png" }
        if data.count > 12, String(data: data[8..<12], encoding: .ascii) == "WEBP" { return "image/webp" }
        return "image/jpeg"
    }
}

private struct IconSquare<Content: View>: View {
    var background: Color
    @ViewBuilder var content: Content
    var body: some View { RoundedRectangle(cornerRadius: 14).fill(background).frame(width: 46, height: 46).overlay(content.font(.system(size: 19, weight: .semibold))) }
}

private struct TrafficStat: View {
    let title: String; let value: String; let icon: String
    var body: some View {
        VStack(spacing: 5) {
            Text(title).font(.caption).foregroundStyle(Theme.textSecondary)
            HStack(spacing: 6) { Text(value).font(.system(size: 14, weight: .semibold)).foregroundStyle(.white); Image(systemName: icon).foregroundStyle(Theme.textSecondary) }
        }
    }
}

private struct PowerButton: View {
    var state: VPNState; var action: () -> Void
    private var iconColor: Color { switch state { case .disconnected, .error: return .white.opacity(0.75); case .connecting: return Theme.premiumYellow; case .connected: return Theme.connectedGreen } }
    var body: some View {
        Button(action: action) {
            ZStack {
                Circle().fill(Theme.ringOuter).frame(width: 260, height: 260)
                Circle().fill(Theme.ringMiddle).frame(width: 210, height: 210)
                Circle().fill(LinearGradient(colors: [Color.white.opacity(0.10), Color.white.opacity(0.02)], startPoint: .top, endPoint: .bottom)).frame(width: 160, height: 160).overlay(Circle().stroke(Color.white.opacity(0.08)))
                Image(systemName: "power").font(.system(size: 58, weight: .light)).foregroundStyle(iconColor)
            }
        }.buttonStyle(.plain).animation(.easeInOut(duration: 0.25), value: state)
    }
}

private struct WorldMapBackground: View {
    var body: some View {
        Canvas { context, size in
            var stripes = Path(); let step: CGFloat = 7; var x: CGFloat = -size.height
            while x < size.width { stripes.move(to: CGPoint(x: x, y: 0)); stripes.addLine(to: CGPoint(x: x + size.height, y: size.height)); x += step }
            context.clip(to: blobs(in: size)); context.stroke(stripes, with: .color(.white.opacity(0.05)), lineWidth: 1.5)
        }.ignoresSafeArea().allowsHitTesting(false)
    }
    private func blobs(in size: CGSize) -> Path {
        var p = Path(); p.addEllipse(in: CGRect(x: size.width * 0.45, y: -40, width: 260, height: 220)); p.addEllipse(in: CGRect(x: -60, y: size.height * 0.18, width: 240, height: 260)); p.addEllipse(in: CGRect(x: size.width * 0.55, y: size.height * 0.34, width: 300, height: 240)); p.addEllipse(in: CGRect(x: size.width * 0.10, y: size.height * 0.60, width: 220, height: 200)); return p
    }
}

private func statusFA(_ status: String) -> String { switch status { case "approved": return "تأیید شد"; case "rejected": return "رد شد"; default: return "در انتظار بررسی" } }
