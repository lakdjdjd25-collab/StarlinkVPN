import Foundation

enum AppConfig {
    static let brand = "Starlink Vpn"
    static let panelBaseURL = URL(string: "https://starlinkpanel.infinityfreeapp.com")!
    static let telegramURL = URL(string: "https://t.me/starlink_vpnx")!
    static let providerBundleIdentifier = "com.starlink.vpn.ios.PacketTunnel"
    static let dns = "1.1.1.1"
    static let metricsPort = 49227
}
