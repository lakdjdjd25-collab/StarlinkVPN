import Foundation

enum XrayConfigBuilder {
    static func build(server: VPNServer, tunFD: Int32? = nil) throws -> String {
        var root: [String: Any] = [
            "log": ["loglevel": "warning"],
            "dns": ["servers": [AppConfig.dns, "8.8.8.8"]],
            "inbounds": [[
                "tag": "tun-in", "port": 0, "protocol": "tun",
                "settings": ["name": "xray-tun", "mtu": 1500],
                "sniffing": ["enabled": true, "routeOnly": false, "destOverride": ["http", "tls", "quic"]]
            ]],
            "outbounds": [try outbound(server), ["tag": "direct", "protocol": "freedom"], ["tag": "block", "protocol": "blackhole"]],
            "routing": ["domainStrategy": "IPIfNonMatch", "rules": []],
            "policy": ["system": ["statsInboundDownlink": true, "statsInboundUplink": true, "statsOutboundDownlink": true, "statsOutboundUplink": true]],
            "stats": [:],
            "metrics": ["listen": "127.0.0.1:\(AppConfig.metricsPort)"]
        ]
        if let tunFD { root["env"] = ["xray.tun.fd": String(tunFD)] }
        let data = try JSONSerialization.data(withJSONObject: root)
        return String(decoding: data, as: UTF8.self)
    }

    static func attachTunFD(_ config: String, fd: Int32) throws -> String {
        guard var root = try JSONSerialization.jsonObject(with: Data(config.utf8)) as? [String: Any] else { throw XrayConfigError.invalid }
        root["env"] = ["xray.tun.fd": String(fd)]
        return String(decoding: try JSONSerialization.data(withJSONObject: root), as: UTF8.self)
    }

    private static func outbound(_ server: VPNServer) throws -> [String: Any] {
        switch server.protocolName {
        case "vmess": return try vmess(server)
        case "trojan": return try trojan(server)
        case "shadowsocks": return try shadowsocks(server)
        default: return try vless(server)
        }
    }

    private static func vmess(_ server: VPNServer) throws -> [String: Any] {
        let encoded = String(server.rawURI.dropFirst("vmess://".count))
        guard let data = Data(base64Encoded: padded(encoded), options: .ignoreUnknownCharacters),
              let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw XrayConfigError.invalid }
        let id = json["id"] as? String ?? ""
        let aid = Int(String(describing: json["aid"] ?? "0")) ?? 0
        let user: [String: Any] = ["id": id, "alterId": aid, "security": json["scy"] as? String ?? "auto"]
        let settings: [String: Any] = ["vnext": [["address": server.address, "port": server.port, "users": [user]]]]
        return ["tag": "proxy", "protocol": "vmess", "settings": settings,
                "streamSettings": stream(network: json["net"] as? String ?? "tcp", security: json["tls"] as? String, host: json["host"] as? String, path: json["path"] as? String, sni: json["sni"] as? String, query: ["fp": json["fp"] as? String ?? ""])]
    }

    private static func vless(_ server: VPNServer) throws -> [String: Any] {
        guard let c = URLComponents(string: server.rawURI) else { throw XrayConfigError.invalid }
        let q = query(c)
        var user: [String: Any] = ["id": c.user ?? "", "encryption": q["encryption"] ?? "none"]
        if let flow = q["flow"], !flow.isEmpty { user["flow"] = flow }
        let settings: [String: Any] = ["vnext": [["address": server.address, "port": server.port, "users": [user]]]]
        return ["tag": "proxy", "protocol": "vless", "settings": settings,
                "streamSettings": stream(network: q["type"] ?? "tcp", security: q["security"], host: q["host"], path: q["path"], sni: q["sni"], query: q)]
    }

    private static func trojan(_ server: VPNServer) throws -> [String: Any] {
        guard let c = URLComponents(string: server.rawURI) else { throw XrayConfigError.invalid }
        let q = query(c)
        return ["tag": "proxy", "protocol": "trojan",
                "settings": ["servers": [["address": server.address, "port": server.port, "password": c.user ?? ""]]],
                "streamSettings": stream(network: q["type"] ?? "tcp", security: q["security"] ?? "tls", host: q["host"], path: q["path"], sni: q["sni"], query: q)]
    }

    private static func shadowsocks(_ server: VPNServer) throws -> [String: Any] {
        let noFragment = server.rawURI.components(separatedBy: "#")[0]
        var body = String(noFragment.dropFirst("ss://".count))
        if !body.contains("@"), let data = Data(base64Encoded: padded(body.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")), options: .ignoreUnknownCharacters), let decoded = String(data: data, encoding: .utf8) { body = decoded }
        let credentialRaw = body.components(separatedBy: "@").first ?? ""
        let credential = Data(base64Encoded: padded(credentialRaw), options: .ignoreUnknownCharacters).flatMap { String(data: $0, encoding: .utf8) } ?? credentialRaw
        let method = credential.components(separatedBy: ":").first ?? ""
        let password = credential.dropFirst(min(credential.count, method.count + 1))
        return ["tag": "proxy", "protocol": "shadowsocks", "settings": ["servers": [["address": server.address, "port": server.port, "method": method, "password": String(password)]]]]
    }

    private static func stream(network: String, security: String?, host: String?, path: String?, sni: String?, query: [String: String]) -> [String: Any] {
        var result: [String: Any] = ["network": network]
        if security == "tls" {
            var tls: [String: Any] = [:]
            if let sni, !sni.isEmpty { tls["serverName"] = sni }
            if let fp = query["fp"], !fp.isEmpty { tls["fingerprint"] = fp }
            result["security"] = "tls"; result["tlsSettings"] = tls
        } else if security == "reality" {
            var reality: [String: Any] = [:]
            if let sni, !sni.isEmpty { reality["serverName"] = sni }
            if let fp = query["fp"] { reality["fingerprint"] = fp }
            if let pbk = query["pbk"] { reality["publicKey"] = pbk }
            if let sid = query["sid"] { reality["shortId"] = sid }
            if let spx = query["spx"] { reality["spiderX"] = spx }
            result["security"] = "reality"; result["realitySettings"] = reality
        }
        switch network {
        case "ws": result["wsSettings"] = ["path": path ?? "/", "headers": ["Host": host ?? ""]]
        case "grpc": result["grpcSettings"] = ["serviceName": (path ?? "").trimmingCharacters(in: CharacterSet(charactersIn: "/"))]
        case "httpupgrade": result["httpupgradeSettings"] = ["path": path ?? "/", "host": host ?? ""]
        case "xhttp", "splithttp": result["xhttpSettings"] = ["path": path ?? "/", "host": host ?? "", "mode": query["mode"] ?? "auto"]
        default: break
        }
        return result
    }

    private static func query(_ components: URLComponents) -> [String: String] { Dictionary(uniqueKeysWithValues: (components.queryItems ?? []).map { ($0.name, $0.value ?? "") }) }
    private static func padded(_ value: String) -> String { value + String(repeating: "=", count: (4 - value.count % 4) % 4) }
}

enum XrayConfigError: LocalizedError { case invalid; var errorDescription: String? { "کانفیگ سرور معتبر نیست." } }
