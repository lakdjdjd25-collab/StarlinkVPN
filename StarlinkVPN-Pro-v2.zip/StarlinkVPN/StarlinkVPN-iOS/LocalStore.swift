import Foundation

final class LocalStore {
    private let defaults = UserDefaults.standard
    var subscriptionURL: URL? {
        get { defaults.string(forKey: "subscription_url").flatMap(URL.init(string:)) }
        set { defaults.set(newValue?.absoluteString, forKey: "subscription_url") }
    }
    var contact: String {
        get { defaults.string(forKey: "contact") ?? "" }
        set { defaults.set(newValue, forKey: "contact") }
    }
    var selectedServerURI: String? {
        get { defaults.string(forKey: "selected_server_uri") }
        set { defaults.set(newValue, forKey: "selected_server_uri") }
    }
    var pendingOrder: PendingOrder? {
        get {
            defaults.data(forKey: "pending_order")
                .flatMap { try? JSONDecoder().decode(PendingOrder.self, from: $0) }
        }
        set {
            if let newValue, let data = try? JSONEncoder().encode(newValue) {
                defaults.set(data, forKey: "pending_order")
            } else {
                defaults.removeObject(forKey: "pending_order")
            }
        }
    }
}
