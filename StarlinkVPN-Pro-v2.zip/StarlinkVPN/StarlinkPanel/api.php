<?php
declare(strict_types=1);

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Client-Platform');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') { http_response_code(204); exit; }

$cfg = require __DIR__ . '/config.php';
require __DIR__ . '/helpers.php';
require __DIR__ . '/db.php';

$action = (string)($_GET['action'] ?? '');

try {
    switch ($action) {
        case 'health':
            json_out(['ok' => true, 'service' => 'StarlinkPanel', 'version' => 2, 'time' => gmdate('c')]);

        case 'config':
            json_out([
                'ok' => true,
                'plans' => array_values($cfg['plans']),
                'card' => $cfg['card'],
                'brand' => $cfg['brand'],
                'telegram' => $cfg['telegram_channel'],
                'receipt' => ['required' => true, 'max_bytes' => 5 * 1024 * 1024, 'types' => ['image/jpeg','image/png','image/webp']],
                'poll_seconds' => 8,
            ]);

        case 'submit_receipt':
            if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') json_out(['ok'=>false,'error'=>'متد درخواست نامعتبر است.'], 405);
            $planId = clean_text($_POST['plan_id'] ?? '', 32);
            $contact = clean_text($_POST['contact'] ?? '', 120);
            $plan = find_plan($cfg['plans'], $planId);
            if (!$plan) json_out(['ok'=>false,'error'=>'پلن انتخاب‌شده معتبر نیست.'], 422);
            if ($contact === '' || text_length($contact) < 3) json_out(['ok'=>false,'error'=>'شماره یا شناسه تماس را وارد کنید.'], 422);
            if (empty($_FILES['receipt']) || !is_array($_FILES['receipt'])) json_out(['ok'=>false,'error'=>'تصویر فیش الزامی است.'], 422);

            $upload = $_FILES['receipt'];
            if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) json_out(['ok'=>false,'error'=>'آپلود فیش کامل نشد.'], 422);
            $size = (int)($upload['size'] ?? 0);
            if ($size < 100 || $size > 5 * 1024 * 1024) json_out(['ok'=>false,'error'=>'حجم فیش باید کمتر از ۵ مگابایت باشد.'], 422);
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = (string)$finfo->file((string)$upload['tmp_name']);
            $extensions = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            if (!isset($extensions[$mime])) json_out(['ok'=>false,'error'=>'فقط تصویر JPG، PNG یا WEBP قابل قبول است.'], 422);

            $uploadsDirectory = upload_dir();
            $filename = 'rcpt_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $extensions[$mime];
            $destination = $uploadsDirectory . DIRECTORY_SEPARATOR . $filename;
            if (!move_uploaded_file((string)$upload['tmp_name'], $destination)) throw new RuntimeException('ذخیره فیش روی هاست ناموفق بود.');
            @chmod($destination, 0644);

            $track = generate_track_code();
            $token = random_token(24);
            try {
                $st = db()->prepare('INSERT INTO orders(track_code,order_token,plan_id,contact,receipt_file,receipt_mime,receipt_size,client_platform,updated_at) VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)');
                $st->execute([$track, $token, $planId, $contact, $filename, $mime, $size, client_platform()]);
                audit('order_created', (int)db()->lastInsertId(), $track);
            } catch (Throwable $e) {
                @unlink($destination);
                throw $e;
            }
            json_out(['ok'=>true,'track_code'=>$track,'order_token'=>$token,'status'=>'pending']);

        case 'order_status':
            $track = clean_text($_GET['track'] ?? '', 48);
            $token = clean_text($_GET['token'] ?? '', 128);
            $st = db()->prepare('SELECT track_code,order_token,status,sub_url,note,vpn_username,created_at,decided_at FROM orders WHERE track_code=? LIMIT 1');
            $st->execute([$track]);
            $order = $st->fetch();
            if (!$order) json_out(['ok'=>false,'error'=>'کد رهگیری یافت نشد.'], 404);
            $legacy = empty($order['order_token']);
            if (!$legacy && !same_secret((string)$order['order_token'], $token)) json_out(['ok'=>false,'error'=>'دسترسی به سفارش معتبر نیست.'], 403);
            json_out([
                'ok'=>true,
                'track_code'=>$order['track_code'],
                'status'=>$order['status'],
                'sub_url'=>$order['status']==='approved' ? $order['sub_url'] : null,
                'vpn_username'=>$order['status']==='approved' ? $order['vpn_username'] : null,
                'note'=>$order['note'],
                'created_at'=>$order['created_at'],
                'decided_at'=>$order['decided_at'],
            ]);

        default:
            json_out(['ok'=>false,'error'=>'action نامعتبر است.'], 404);
    }
} catch (Throwable $e) {
    error_log('StarlinkPanel API: ' . $e);
    json_out(['ok'=>false,'error'=>'خطای داخلی پنل رخ داد.'], 500);
}
