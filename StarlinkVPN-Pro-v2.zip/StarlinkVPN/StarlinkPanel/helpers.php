<?php
declare(strict_types=1);

function json_out(array $payload, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function request_ip(): string {
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 0, 64);
}

function text_substr(string $value, int $start, int $length): string {
    return function_exists('mb_substr') ? mb_substr($value, $start, $length, 'UTF-8') : substr($value, $start, $length);
}

function text_length(string $value): int {
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
}

function clean_text(?string $value, int $max = 190): string {
    $value = trim((string)$value);
    $value = preg_replace('/[\x00-\x1F\x7F]/u', '', $value) ?? '';
    return text_substr($value, 0, $max);
}

function random_token(int $bytes = 24): string {
    return rtrim(strtr(base64_encode(random_bytes($bytes)), '+/', '-_'), '=');
}

function generate_track_code(): string {
    return 'SL' . date('ymd') . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
}

function find_plan(array $plans, string $id): ?array {
    foreach ($plans as $plan) {
        if (($plan['id'] ?? null) === $id) return $plan;
    }
    return null;
}

function same_secret(string $expected, string $given): bool {
    return $expected !== '' && $given !== '' && hash_equals($expected, $given);
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = random_token(24);
    return (string)$_SESSION['csrf'];
}

function verify_csrf(): void {
    $token = (string)($_POST['csrf'] ?? '');
    if (!same_secret((string)($_SESSION['csrf'] ?? ''), $token)) {
        throw new RuntimeException('درخواست نامعتبر است. صفحه را تازه‌سازی کنید.', 419);
    }
}


function storage_dir(): string {
    $configured = trim((string)(getenv('STARLINK_DATA_DIR') ?: ''));
    $directory = $configured !== '' ? rtrim($configured, DIRECTORY_SEPARATOR) : __DIR__;
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
        throw new RuntimeException('پوشه ذخیره‌سازی قابل ایجاد نیست.');
    }
    return $directory;
}

function upload_dir(): string {
    $directory = storage_dir() . DIRECTORY_SEPARATOR . 'uploads';
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
        throw new RuntimeException('پوشه uploads قابل ایجاد نیست.');
    }
    return $directory;
}

function safe_receipt_path(string $filename): ?string {
    if (!preg_match('/^rcpt_[a-zA-Z0-9_-]+\.(jpg|jpeg|png|webp)$/i', $filename)) return null;
    $directory = upload_dir();
    $base = realpath($directory);
    $path = realpath($directory . DIRECTORY_SEPARATOR . $filename);
    if (!$base || !$path || !str_starts_with($path, $base . DIRECTORY_SEPARATOR)) return null;
    return $path;
}

function client_platform(): string {
    $value = strtolower(clean_text($_SERVER['HTTP_X_CLIENT_PLATFORM'] ?? 'unknown', 24));
    return in_array($value, ['android', 'ios', 'web'], true) ? $value : 'unknown';
}
