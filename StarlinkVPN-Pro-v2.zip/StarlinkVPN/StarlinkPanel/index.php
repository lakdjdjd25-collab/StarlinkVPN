<?php
declare(strict_types=1);

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
session_set_cookie_params([
    'httponly' => true,
    'secure' => $isHttps,
    'samesite' => 'Lax',
]);
session_start();

$cfg = require __DIR__ . '/config.php';
require __DIR__ . '/helpers.php';
require __DIR__ . '/db.php';
require __DIR__ . '/pasargad.php';

$msg = $_SESSION['flash_msg'] ?? null;
$err = $_SESSION['flash_err'] ?? null;
unset($_SESSION['flash_msg'], $_SESSION['flash_err']);

if (isset($_GET['logout'])) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
    header('Location: index.php');
    exit;
}

if (isset($_POST['login'])) {
    $attempts = (int)($_SESSION['login_attempts'] ?? 0);
    $lockedUntil = (int)($_SESSION['login_locked_until'] ?? 0);
    if ($lockedUntil > time()) {
        $err = 'تلاش‌های ناموفق زیاد بوده است. چند دقیقه بعد دوباره امتحان کنید.';
    } elseif (hash_equals((string)$cfg['panel_password'], (string)($_POST['password'] ?? ''))) {
        session_regenerate_id(true);
        $_SESSION['auth'] = true;
        $_SESSION['login_attempts'] = 0;
        $_SESSION['login_locked_until'] = 0;
        audit('admin_login');
        header('Location: index.php');
        exit;
    } else {
        $attempts++;
        $_SESSION['login_attempts'] = $attempts;
        if ($attempts >= 7) $_SESSION['login_locked_until'] = time() + 300;
        $err = 'رمز اشتباه است.';
        audit('admin_login_failed', null, 'attempt=' . $attempts);
    }
}

$authed = !empty($_SESSION['auth']);

if ($authed && isset($_GET['receipt'])) {
    $id = (int)$_GET['receipt'];
    $st = db()->prepare('SELECT receipt_file,receipt_mime FROM orders WHERE id=?');
    $st->execute([$id]);
    $row = $st->fetch();
    $path = $row ? safe_receipt_path((string)$row['receipt_file']) : null;
    if (!$path) { http_response_code(404); exit('فیش یافت نشد.'); }
    header('Content-Type: ' . ((string)$row['receipt_mime'] ?: 'application/octet-stream'));
    header('Content-Length: ' . filesize($path));
    header('Content-Disposition: inline; filename="receipt-' . $id . '"');
    header('X-Content-Type-Options: nosniff');
    readfile($path);
    exit;
}

if ($authed && ($_SERVER['REQUEST_METHOD'] ?? '') === 'POST' && isset($_POST['act'])) {
    try {
        verify_csrf();
        $id = (int)($_POST['id'] ?? 0);
        $st = db()->prepare('SELECT * FROM orders WHERE id=? LIMIT 1');
        $st->execute([$id]);
        $order = $st->fetch();
        if (!$order) throw new RuntimeException('سفارش پیدا نشد.');
        $plan = find_plan($cfg['plans'], (string)$order['plan_id']);
        if (!$plan) throw new RuntimeException('پلن سفارش در config.php وجود ندارد.');

        if ($_POST['act'] === 'approve') {
            if ($order['status'] === 'approved' && !empty($order['sub_url'])) {
                $_SESSION['flash_msg'] = 'این سفارش قبلاً تأیید شده است.';
            } else {
                $username = 'sl_' . strtolower(preg_replace('/[^a-zA-Z0-9_]/', '', (string)$order['track_code']));
                db()->prepare('UPDATE orders SET last_error=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$id]);
                $api = new PasargadAPI($cfg['pasargad']);
                $result = $api->createOrGetUser($username, (int)$plan['days'], (int)$plan['gb']);
                $payload = json_encode($result['raw'] ?? [], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                $up = db()->prepare('UPDATE orders SET status="approved",vpn_username=?,sub_url=?,approved_payload=?,note=NULL,last_error=NULL,decided_at=COALESCE(decided_at,CURRENT_TIMESTAMP),updated_at=CURRENT_TIMESTAMP WHERE id=?');
                $up->execute([$result['username'], $result['sub_url'], $payload, $id]);
                audit('order_approved', $id, (string)$result['username']);
                $_SESSION['flash_msg'] = 'سفارش تأیید شد و لینک اشتراک برای برنامه آماده است.';
            }
        } elseif ($_POST['act'] === 'reject') {
            $note = clean_text($_POST['note'] ?? 'فیش تأیید نشد', 300);
            if ($note === '') $note = 'فیش تأیید نشد';
            db()->prepare('UPDATE orders SET status="rejected",note=?,last_error=NULL,decided_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$note, $id]);
            audit('order_rejected', $id, $note);
            $_SESSION['flash_msg'] = 'سفارش رد شد.';
        } elseif ($_POST['act'] === 'retry') {
            db()->prepare('UPDATE orders SET status="pending",note=NULL,last_error=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([$id]);
            audit('order_retry', $id);
            $_SESSION['flash_msg'] = 'سفارش دوباره در انتظار بررسی قرار گرفت.';
        }
    } catch (Throwable $e) {
        if (!empty($id)) {
            db()->prepare('UPDATE orders SET last_error=?,updated_at=CURRENT_TIMESTAMP WHERE id=?')->execute([text_substr($e->getMessage(), 0, 500), $id]);
            audit('order_action_error', $id, $e->getMessage());
        }
        $_SESSION['flash_err'] = $e->getMessage();
    }
    header('Location: index.php' . (!empty($_GET['status']) ? '?status=' . rawurlencode((string)$_GET['status']) : ''));
    exit;
}

$stats = null;
$pasargadOk = false;
$pasargadError = null;
if ($authed) {
    try {
        $stats = (new PasargadAPI($cfg['pasargad']))->systemStats();
        $pasargadOk = true;
    } catch (Throwable $e) {
        $pasargadError = $e->getMessage();
    }
}

$statusFilter = clean_text($_GET['status'] ?? '', 20);
if (!in_array($statusFilter, ['', 'pending', 'approved', 'rejected'], true)) $statusFilter = '';
$search = clean_text($_GET['q'] ?? '', 80);
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 30;
$where = [];
$params = [];
if ($statusFilter !== '') { $where[] = 'status=?'; $params[] = $statusFilter; }
if ($search !== '') { $where[] = '(track_code LIKE ? OR contact LIKE ? OR vpn_username LIKE ?)'; $like = '%' . $search . '%'; array_push($params, $like, $like, $like); }
$whereSql = $where ? ' WHERE ' . implode(' AND ', $where) : '';
$countSt = db()->prepare('SELECT COUNT(*) FROM orders' . $whereSql);
$countSt->execute($params);
$total = (int)$countSt->fetchColumn();
$pages = max(1, (int)ceil($total / $perPage));
$page = min($page, $pages);
$listSt = db()->prepare('SELECT * FROM orders' . $whereSql . ' ORDER BY id DESC LIMIT ' . $perPage . ' OFFSET ' . (($page - 1) * $perPage));
$listSt->execute($params);
$orders = $listSt->fetchAll();

$summary = ['pending'=>0,'approved'=>0,'rejected'=>0,'total'=>0];
if ($authed) {
    foreach (db()->query('SELECT status,COUNT(*) c FROM orders GROUP BY status') as $r) $summary[$r['status']] = (int)$r['c'];
    $summary['total'] = array_sum([$summary['pending'], $summary['approved'], $summary['rejected']]);
}
$pmap = [];
foreach ($cfg['plans'] as $p) $pmap[$p['id']] = $p;
function h(mixed $v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function order_status_fa(string $status): string { return ['pending'=>'در انتظار','approved'=>'تأیید','rejected'=>'رد'][$status] ?? $status; }
?><!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>پنل مدیریت Starlink VPN</title>
<style>
*{box-sizing:border-box;font-family:Tahoma,system-ui,sans-serif}body{margin:0;background:#14131c;color:#eee}.top{background:#1B1A21;padding:16px 24px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #2a2a35;position:sticky;top:0;z-index:5}.top h1{font-size:18px;margin:0;color:#F4B912}.wrap{max-width:1180px;margin:24px auto;padding:0 16px}.card{background:#1e1d28;border:1px solid #2a2a35;border-radius:12px;padding:18px;margin-bottom:16px}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.metric{background:#171620;border:1px solid #2a2a35;border-radius:10px;padding:14px}.metric small{color:#9a99a8}.metric strong{display:block;font-size:23px;margin-top:6px;color:#fff}.toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.toolbar input,.toolbar select{width:auto;min-width:180px}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;min-width:940px}th,td{padding:10px;border-bottom:1px solid #2a2a35;text-align:right;font-size:14px;vertical-align:top}th{color:#9a99a8}.badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px}.pending{background:#403716;color:#F4B912}.approved{background:#1e3a1e;color:#8CE322}.rejected{background:#3a1e1e;color:#E14840}.btn{border:none;border-radius:8px;padding:8px 14px;cursor:pointer;font-size:13px;color:#fff;text-decoration:none;display:inline-block}.ok{background:#2e7d32}.no{background:#c62828}.neutral{background:#3b3a49}.yellow{background:#8b6a00}input,select{background:#14131c;border:1px solid #2a2a35;color:#fff;border-radius:8px;padding:10px;width:100%}a.rc{color:#2AA3E0}.pill{background:#2a2a35;color:#ccc;padding:4px 10px;border-radius:8px;font-size:12px}.muted{color:#9a99a8;font-size:12px}.actions{display:flex;gap:6px;flex-wrap:wrap}.inline{display:inline}.error-detail{margin-top:5px;color:#ff8b85;font-size:11px;max-width:240px;white-space:normal}.pagination{display:flex;gap:6px;justify-content:center;margin-top:16px}.pagination a{color:#fff;text-decoration:none;background:#2a2a35;padding:7px 11px;border-radius:8px}.pagination a.active{background:#8b6a00}.receipt{max-width:130px}.login-card{max-width:360px;margin:60px auto}@media(max-width:760px){.grid{grid-template-columns:repeat(2,1fr)}.top{padding:14px 16px}.top h1{font-size:15px}.wrap{margin-top:14px}.toolbar input,.toolbar select{width:100%}}
</style></head><body>
<div class="top"><h1>🛡️ پنل مدیریت Starlink VPN</h1><?php if($authed):?><a class="btn no" href="?logout=1">خروج</a><?php endif;?></div>
<div class="wrap">
<?php if($msg):?><div class="card" style="border-color:#2e7d32">✅ <?=h($msg)?></div><?php endif;?>
<?php if($err):?><div class="card" style="border-color:#c62828">⚠️ <?=h($err)?></div><?php endif;?>
<?php if(!$authed):?>
<div class="card login-card"><h3>ورود مدیر</h3><form method="post"><input type="password" name="password" placeholder="رمز پنل" autocomplete="current-password" required><br><br><button class="btn ok" name="login" value="1" style="width:100%">ورود</button></form></div>
<?php else:?>
<div class="grid">
<div class="metric"><small>کل سفارش‌ها</small><strong><?=$summary['total']?></strong></div>
<div class="metric"><small>در انتظار</small><strong style="color:#F4B912"><?=$summary['pending']?></strong></div>
<div class="metric"><small>تأییدشده</small><strong style="color:#8CE322"><?=$summary['approved']?></strong></div>
<div class="metric"><small>ردشده</small><strong style="color:#E14840"><?=$summary['rejected']?></strong></div>
</div><br>
<div class="card"><b>وضعیت پاسارگاد:</b> <?php if($pasargadOk):?><span class="badge approved">متصل</span> <span class="pill">کاربران فعال: <?=h($stats['users_active']??'-')?></span><?php else:?><span class="badge rejected">قطع</span> <small><?=h($pasargadError ?: 'اتصال برقرار نشد')?></small><?php endif;?></div>
<div class="card">
<div class="toolbar"><h3 style="margin:0 auto 0 0">🧾 مدیریت فیش‌ها</h3>
<form method="get" class="toolbar"><input name="q" value="<?=h($search)?>" placeholder="کد رهگیری، تماس یا نام کاربر"><select name="status"><option value="">همه وضعیت‌ها</option><option value="pending" <?=$statusFilter==='pending'?'selected':''?>>در انتظار</option><option value="approved" <?=$statusFilter==='approved'?'selected':''?>>تأیید</option><option value="rejected" <?=$statusFilter==='rejected'?'selected':''?>>رد</option></select><button class="btn neutral">جستجو</button></form>
</div><br>
<div class="table-wrap"><table><tr><th>کد و زمان</th><th>پلن</th><th>مخاطب</th><th>فیش</th><th>وضعیت و سرویس</th><th>عملیات</th></tr>
<?php if(!$orders):?><tr><td colspan="6" class="muted">سفارشی پیدا نشد.</td></tr><?php endif;?>
<?php foreach($orders as $o):$p=$pmap[$o['plan_id']]??null;?>
<tr><td><b><?=h($o['track_code'])?></b><br><span class="muted"><?=h($o['created_at'])?> · <?=h($o['client_platform']??'unknown')?></span></td>
<td><?=$p?h($p['title']).'<br><span class="muted">'.number_format((int)$p['price']).' تومان · '.(int)$p['gb'].'GB</span>':h($o['plan_id'])?></td>
<td><?=h($o['contact']?:'-')?></td>
<td><?php if($o['receipt_file']):?><a class="rc" target="_blank" href="?receipt=<?=(int)$o['id']?>">مشاهده فیش</a><br><span class="muted"><?=number_format(((int)($o['receipt_size']??0))/1024,1)?> KB</span><?php else:?>-<?php endif;?></td>
<td><span class="badge <?=h($o['status'])?>"><?=h(order_status_fa((string)$o['status']))?></span>
<?php if($o['sub_url']):?><br><small><a class="rc" target="_blank" rel="noopener" href="<?=h($o['sub_url'])?>">لینک اشتراک</a></small><?php endif;?>
<?php if($o['vpn_username']):?><br><span class="muted"><?=h($o['vpn_username'])?></span><?php endif;?>
<?php if($o['note']):?><br><span class="muted"><?=h($o['note'])?></span><?php endif;?>
<?php if($o['last_error']):?><div class="error-detail"><?=h($o['last_error'])?></div><?php endif;?></td>
<td><div class="actions">
<?php if($o['status']==='pending'):?>
<form method="post" class="inline"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="id" value="<?=(int)$o['id']?>"><button class="btn ok" name="act" value="approve" onclick="return confirm('فیش تأیید و سرویس پاسارگاد ساخته شود؟')">تأیید و ارسال</button></form>
<form method="post" class="inline" onsubmit="this.note.value=prompt('دلیل رد فیش:','فیش تأیید نشد')||'فیش تأیید نشد'"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="id" value="<?=(int)$o['id']?>"><input type="hidden" name="note" value=""><button class="btn no" name="act" value="reject">رد</button></form>
<?php elseif($o['status']==='rejected'):?>
<form method="post" class="inline"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="id" value="<?=(int)$o['id']?>"><button class="btn yellow" name="act" value="retry">بررسی دوباره</button></form>
<?php else:?><span class="muted">تحویل خودکار انجام شد</span><?php endif;?>
</div></td></tr>
<?php endforeach;?></table></div>
<?php if($pages>1):?><div class="pagination"><?php for($i=1;$i<=$pages;$i++):$qs=http_build_query(['status'=>$statusFilter,'q'=>$search,'page'=>$i]);?><a class="<?=$i===$page?'active':''?>" href="?<?=$qs?>"><?=$i?></a><?php endfor;?></div><?php endif;?>
</div>
<?php endif;?></div></body></html>
