<?php
return [
  'panel_password' => 'Starlink@Admin2024!',  // رمز ورود به پنل مدیریت — می‌توانید عوض کنید

  'pasargad' => [
    'base_url' => 'https://panel-marz.lmsmarket.monster',
    'username' => 'V2net1212',
    'password' => 'dtp+C3U4dL\>9',
  ],

  'card' => [
    'number' => '6219-8618-8298-3777',
    'holder' => 'هاشمی',
  ],

  'plans' => [
    ['id'=>'p30','title'=>'یک ماهه','days'=>30,'gb'=>50, 'price'=>69000],
    ['id'=>'p60','title'=>'دو ماهه','days'=>60,'gb'=>120,'price'=>130000],
    ['id'=>'p90','title'=>'سه ماهه','days'=>90,'gb'=>200,'price'=>199000],
  ],

  'telegram_channel' => 'https://t.me/starlink_vpnx',
  'brand'            => 'Starlink Vpn',
];
