<?php
declare(strict_types=1);

function db(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $pdo = new PDO('sqlite:' . storage_dir() . '/data.db', null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    $pdo->exec('PRAGMA journal_mode=WAL');
    $pdo->exec('PRAGMA busy_timeout=5000');
    $pdo->exec('PRAGMA foreign_keys=ON');

    $pdo->exec('CREATE TABLE IF NOT EXISTS orders(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      track_code TEXT UNIQUE NOT NULL,
      plan_id TEXT NOT NULL,
      contact TEXT,
      receipt_file TEXT,
      status TEXT DEFAULT "pending",
      vpn_username TEXT,
      sub_url TEXT,
      note TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      decided_at TEXT
    )');

    $columns = [];
    foreach ($pdo->query('PRAGMA table_info(orders)') as $row) $columns[$row['name']] = true;
    $migrations = [
        'order_token' => 'ALTER TABLE orders ADD COLUMN order_token TEXT',
        'receipt_mime' => 'ALTER TABLE orders ADD COLUMN receipt_mime TEXT',
        'receipt_size' => 'ALTER TABLE orders ADD COLUMN receipt_size INTEGER DEFAULT 0',
        'client_platform' => 'ALTER TABLE orders ADD COLUMN client_platform TEXT DEFAULT "unknown"',
        'updated_at' => 'ALTER TABLE orders ADD COLUMN updated_at TEXT',
        'approved_payload' => 'ALTER TABLE orders ADD COLUMN approved_payload TEXT',
        'last_error' => 'ALTER TABLE orders ADD COLUMN last_error TEXT',
    ];
    foreach ($migrations as $column => $sql) {
        if (empty($columns[$column])) $pdo->exec($sql);
    }

    $pdo->exec('CREATE INDEX IF NOT EXISTS idx_orders_status_created ON orders(status, created_at DESC)');
    $pdo->exec('CREATE INDEX IF NOT EXISTS idx_orders_track ON orders(track_code)');
    $pdo->exec('CREATE TABLE IF NOT EXISTS audit_log(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      action TEXT NOT NULL,
      order_id INTEGER,
      detail TEXT,
      ip TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )');

    return $pdo;
}

function audit(string $action, ?int $orderId = null, string $detail = ''): void {
    try {
        $st = db()->prepare('INSERT INTO audit_log(action,order_id,detail,ip) VALUES(?,?,?,?)');
        $st->execute([$action, $orderId, text_substr($detail, 0, 1000), request_ip()]);
    } catch (Throwable $ignored) {}
}
