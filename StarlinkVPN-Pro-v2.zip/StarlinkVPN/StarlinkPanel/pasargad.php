<?php
declare(strict_types=1);

final class PasargadHttpException extends RuntimeException {
    public function __construct(public readonly int $status, string $message) {
        parent::__construct($message, $status);
    }
}

final class PasargadAPI {
    private string $base;
    private string $user;
    private string $pass;
    private ?string $token = null;

    public function __construct(array $config) {
        $this->base = rtrim((string)$config['base_url'], '/');
        $this->user = (string)$config['username'];
        $this->pass = (string)$config['password'];
    }

    private function http(string $method, string $path, mixed $body = null, array $headers = [], bool $form = false, bool $retryAuth = true): array {
        $ch = curl_init($this->base . $path);
        $httpHeaders = array_merge(['Accept: application/json'], $headers);
        $payload = null;
        if ($body !== null) {
            if ($form) {
                $payload = http_build_query($body);
                $httpHeaders[] = 'Content-Type: application/x-www-form-urlencoded';
            } else {
                $payload = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                $httpHeaders[] = 'Content-Type: application/json';
            }
        }
        curl_setopt_array($ch, [
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $httpHeaders,
            CURLOPT_CONNECTTIMEOUT => 12,
            CURLOPT_TIMEOUT => 35,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'StarlinkPanel/2.0',
        ]);
        if ($payload !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);

        $raw = curl_exec($ch);
        if ($raw === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new RuntimeException('خطای اتصال به پاسارگاد: ' . $error);
        }
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $json = json_decode($raw, true);

        if ($status === 401 && $retryAuth && str_starts_with(implode('|', $headers), 'Authorization:')) {
            $this->token = null;
            $newHeaders = array_values(array_filter($headers, fn($h) => !str_starts_with($h, 'Authorization:')));
            $newHeaders[] = 'Authorization: Bearer ' . $this->login();
            return $this->http($method, $path, $body, $newHeaders, $form, false);
        }
        if ($status < 200 || $status >= 300) {
            $detail = is_array($json) ? ($json['detail'] ?? $json['message'] ?? null) : null;
            if (is_array($detail)) $detail = json_encode($detail, JSON_UNESCAPED_UNICODE);
            throw new PasargadHttpException($status, 'خطای پاسارگاد (' . $status . '): ' . ($detail ?: text_substr($raw, 0, 500)));
        }
        return is_array($json) ? $json : [];
    }

    public function login(): string {
        if ($this->token !== null) return $this->token;
        $result = $this->http('POST', '/api/admin/token', [
            'username' => $this->user,
            'password' => $this->pass,
        ], [], true, false);
        $token = (string)($result['access_token'] ?? '');
        if ($token === '') throw new RuntimeException('توکن ورود از پاسارگاد دریافت نشد.');
        return $this->token = $token;
    }

    private function auth(): array {
        return ['Authorization: Bearer ' . $this->login()];
    }

    public function getUser(string $username): array {
        return $this->http('GET', '/api/user/' . rawurlencode($username), null, $this->auth());
    }

    public function createUser(string $username, int $days, int $gb): array {
        $expire = time() + max(1, $days) * 86400;
        $payload = [
            'username' => $username,
            'proxies' => ['vless' => new stdClass()],
            'inbounds' => new stdClass(),
            'expire' => $expire,
            'data_limit' => max(0, $gb) * 1073741824,
            'data_limit_reset_strategy' => 'no_reset',
            'status' => 'active',
        ];
        return $this->normalizeUser($this->http('POST', '/api/user', $payload, $this->auth()), $username);
    }

    public function createOrGetUser(string $username, int $days, int $gb): array {
        try {
            return $this->normalizeUser($this->getUser($username), $username);
        } catch (PasargadHttpException $e) {
            if ($e->status !== 404) throw $e;
        }
        try {
            return $this->createUser($username, $days, $gb);
        } catch (PasargadHttpException $e) {
            if (!in_array($e->status, [400, 409], true)) throw $e;
            return $this->normalizeUser($this->getUser($username), $username);
        }
    }

    private function normalizeUser(array $user, string $fallbackUsername): array {
        $subscription = (string)($user['subscription_url'] ?? $user['subscriptionUrl'] ?? '');
        if ($subscription !== '' && str_starts_with($subscription, '/')) $subscription = $this->base . $subscription;
        if ($subscription === '' && !empty($user['subscription_token'])) {
            $subscription = $this->base . '/sub/' . rawurlencode((string)$user['subscription_token']);
        }
        if ($subscription === '') throw new RuntimeException('کاربر ساخته شد اما لینک اشتراک از پاسارگاد دریافت نشد.');
        return [
            'username' => (string)($user['username'] ?? $fallbackUsername),
            'sub_url' => $subscription,
            'raw' => $user,
        ];
    }

    public function deleteUser(string $username): void {
        $this->http('DELETE', '/api/user/' . rawurlencode($username), null, $this->auth());
    }

    public function systemStats(): array {
        return $this->http('GET', '/api/system', null, $this->auth());
    }
}
